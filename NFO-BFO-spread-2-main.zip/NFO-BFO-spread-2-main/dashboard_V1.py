# ─────────────────────────────────────────────
# dashboard.py — Single file, no external imports
# Run with: streamlit run dashboard.py
# ─────────────────────────────────────────────

import os
import base64
import hashlib
import pyotp
import requests
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import time
from datetime import date
from urllib.parse import parse_qs, urlparse
from plotly.subplots import make_subplots
import numpy as np
from scipy.stats import norm
from scipy.optimize import brentq
from fyers_apiv3 import fyersModel


# ─────────────────────────────────────────────
# CONFIG — edit these or set as env variables
# ─────────────────────────────────────────────

CLIENT_ID       = os.environ.get("FYERS_CLIENT_ID",  "YOUR_APP_ID-100")
SECRET_KEY      = os.environ.get("FYERS_SECRET_KEY", "YOUR_SECRET_KEY")
TOKEN_FILE      = "access_token.txt"
REFRESH_SECONDS = 10

# ─────────────────────────────────────────────
# AUTO TOKEN (TOTP)
# ─────────────────────────────────────────────

def get_secret(key):
    try:
        if key in st.secrets:
            return str(st.secrets[key])
    except Exception:
        pass
    return os.environ.get(key, "")

def b64(value):
    return base64.b64encode(str(value).encode()).decode()

def generate_token(client_id, secret_key, username, pin, totp_key):
    """All credentials passed explicitly — never reads st.secrets inside cached context."""
    redirect_uri = "http://127.0.0.1:8080/"

    try:
        s = requests.Session()
        r1 = s.post("https://api-t2.fyers.in/vagator/v2/send_login_otp_v2",
                    json={"fy_id": b64(username), "app_id": "2"}, timeout=10)
        if r1.status_code == 429:
            return None, "Rate limited by Fyers (429). Wait ~60s then click Refresh Token."
        try:
            r1d = r1.json()
        except Exception:
            return None, f"Step 1 bad response (status {r1.status_code}): {r1.text[:200]}"
        if r1d.get("s") != "ok":
            return None, f"Step 1 failed: {r1d}"

        totp_code = pyotp.TOTP(totp_key).now()
        r2 = s.post("https://api-t2.fyers.in/vagator/v2/verify_otp",
                    json={"request_key": r1d["request_key"], "otp": totp_code}, timeout=10)
        r2d = r2.json()
        if r2d.get("s") != "ok":
            return None, f"Step 2 failed: {r2d}"

        r3 = s.post("https://api-t2.fyers.in/vagator/v2/verify_pin_v2",
                    json={"request_key": r2d["request_key"], "identity_type": "pin", "identifier": b64(pin)}, timeout=10)
        r3d = r3.json()
        if r3d.get("s") != "ok":
            return None, f"Step 3 failed: {r3d}"

        app_id = client_id.split("-")[0]
        r4 = s.post("https://api-t1.fyers.in/api/v3/token", json={
            "fyers_id": username, "app_id": app_id, "redirect_uri": redirect_uri,
            "appType": "100", "code_challenge": "", "state": "sample",
            "scope": "", "nonce": "", "response_type": "code", "create_cookie": True
        }, headers={"Authorization": f"Bearer {r3d['data']['access_token']}"}, timeout=10)
        r4d = r4.json()
        if r4d.get("s") != "ok":
            return None, f"Step 4 failed: {r4d}"

        data = r4d.get("data", {})
        auth_code = (
            data.get("auth")
            or parse_qs(urlparse(r4d.get("Url", "")).query).get("auth_code", [None])[0]
            or parse_qs(urlparse(data.get("url", "")).query).get("auth_code", [None])[0]
        )
        if not auth_code:
            return None, f"Step 4: no auth_code in response: {r4d}"

        # New Fyers API: exchange auth_code via validate-authcode using SHA-256 app hash
        app_id_hash = hashlib.sha256(f"{app_id}:{secret_key}".encode()).hexdigest()
        r5 = s.post("https://api-t1.fyers.in/api/v3/validate-authcode", json={
            "grant_type": "authorization_code",
            "appIdHash": app_id_hash,
            "code": auth_code,
        }, timeout=10)
        r5d = r5.json()
        token = r5d.get("access_token")
        if not token:
            # Fallback: try legacy SDK exchange
            session = fyersModel.SessionModel(
                client_id=client_id, secret_key=secret_key,
                redirect_uri=redirect_uri, response_type="code", grant_type="authorization_code"
            )
            session.set_token(auth_code)
            r5d = session.generate_token()
            token = r5d.get("access_token")
        if not token:
            return None, f"Step 5 failed: {r5d}"
        return token, None
    except Exception as e:
        return None, f"Exception: {str(e)}"

# ─────────────────────────────────────────────
# FYERS CLIENT
# ─────────────────────────────────────────────

def load_fyers_from_file():
    if not os.path.exists(TOKEN_FILE):
        raise FileNotFoundError("Token file not found")
    with open(TOKEN_FILE) as f:
        token = f.read().strip()
    return fyersModel.FyersModel(client_id=get_secret("FYERS_CLIENT_ID") or CLIENT_ID, token=token, log_path="")

@st.cache_resource
def _cached_generate_token(client_id, secret_key, username, pin, totp_key):
    """Cached token generator. Args are passed explicitly so st.secrets is read
    in normal Streamlit context (not inside cache thread where it silently fails).
    Returns (token_or_None, error_or_None) — caches failures too to stop retry storm."""
    # Try persisted token file first (avoids login on warm restarts)
    try:
        with open(TOKEN_FILE) as f:
            token = f.read().strip()
        if token:
            return token, None
    except FileNotFoundError:
        pass
    # Auto-generate via TOTP
    token, error = generate_token(client_id, secret_key, username, pin, totp_key)
    if token:
        try:
            with open(TOKEN_FILE, "w") as f:
                f.write(token)
        except Exception:
            pass
        return token, None
    return None, error  # cached failure — stops retry storm

def get_shared_token():
    """Reads secrets in Streamlit context, then calls the cached generator."""
    client_id  = get_secret("FYERS_CLIENT_ID")
    secret_key = get_secret("FYERS_SECRET_KEY")
    username   = get_secret("FYERS_USERNAME")
    pin        = get_secret("FYERS_PIN")
    totp_key   = get_secret("FYERS_TOTP_KEY")

    missing = [k for k, v in {
        "FYERS_CLIENT_ID": client_id, "FYERS_SECRET_KEY": secret_key,
        "FYERS_USERNAME": username, "FYERS_PIN": pin, "FYERS_TOTP_KEY": totp_key,
    }.items() if not v]
    if missing:
        return None, f"Missing credentials: {', '.join(missing)}"

    return _cached_generate_token(client_id, secret_key, username, pin, totp_key)

def get_fyers_client():
    token, error = get_shared_token()
    if not token:
        st.error(f"❌ Login failed: {error}")
        return None
    cid = get_secret("FYERS_CLIENT_ID") or CLIENT_ID
    return fyersModel.FyersModel(client_id=cid, token=token, log_path="")

# ─────────────────────────────────────────────
# EXPIRY FETCHER — cached per token
# ─────────────────────────────────────────────

_UNDERLYING_SYM = {
    "SENSEX":    "BSE:SENSEX-INDEX",
    "BANKEX":    "BSE:BANKEX-INDEX",
    "NIFTY":     "NSE:NIFTY50-INDEX",
    "BANKNIFTY": "NSE:NIFTYBANK-INDEX",
    "FINNIFTY":  "NSE:FINNIFTY-INDEX",
    "MIDCPNIFTY":"NSE:MIDCPNIFTY-INDEX",
    # MCX commodities — option chain symbol format (big contracts)
    "CRUDEOIL":  "MCX:CRUDEOIL-INDEX",
    "GOLD":      "MCX:GOLD-INDEX",
    "SILVER":    "MCX:SILVER-INDEX",
    "NATURALGAS":"MCX:NATURALGAS-INDEX",
    # MCX mini contracts — same -INDEX symbology format
    "CRUDEOILM":  "MCX:CRUDEOILM-INDEX",
    "GOLDM":      "MCX:GOLDM-INDEX",
    "SILVERM":    "MCX:SILVERM-INDEX",
    "NATURALGASM":"MCX:NATURALGASM-INDEX",
}

_MONTHS = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"]

EXPIRY_CACHE_FILE = "expiry_cache.json"

def _load_expiry_cache():
    """Load today's expiry cache from file. Returns {} if missing or stale."""
    try:
        import json
        with open(EXPIRY_CACHE_FILE) as f:
            data = json.load(f)
        if data.get("date") == date.today().isoformat():
            return data.get("expiries", {})
    except Exception:
        pass
    return {}

def _save_expiry_cache(expiries: dict):
    """Persist expiries to file with today's date stamp."""
    import json
    try:
        with open(EXPIRY_CACHE_FILE, "w") as f:
            json.dump({"date": date.today().isoformat(), "expiries": expiries}, f)
    except Exception:
        pass

@st.cache_resource
def _fetch_expiries_from_fyers(client_id, token, fyers_sym):
    """Hits Fyers option chain API. Returns (dict, error_str).

    Honors API's `expiry_flag` field ('M' = monthly, 'W' = weekly) when present;
    falls back to last-day-of-month inference if the flag is missing.
    """
    from collections import defaultdict
    try:
        fyers = fyersModel.FyersModel(client_id=client_id, token=token, log_path="")
        resp = fyers.optionchain(data={"symbol": fyers_sym, "strikecount": 1, "timestamp": ""})
        if not (resp and resp.get("s") == "ok"):
            return {}, f"optionchain API returned: {resp}"
        raw = resp.get("data", {}).get("expiryData", [])

        parsed = []
        for entry in raw:
            if not isinstance(entry, dict): continue
            d = entry.get("date", "")
            flag = (entry.get("expiry_flag") or "").upper()
            try:
                dd, mm, yyyy = d.split("-")
                dd, mm, yyyy = int(dd), int(mm), int(yyyy)
            except Exception:
                continue
            yy  = yyyy % 100
            mon = _MONTHS[mm - 1]
            parsed.append((yy, mm, dd, mon, flag))

        by_month = defaultdict(list)
        for yy, mm, dd, mon, _flag in parsed:
            by_month[(yy, mm)].append(dd)
        last_of_month = {k: max(v) for k, v in by_month.items()}

        result = {}
        for yy, mm, dd, mon, flag in parsed:
            if flag == "M":
                is_monthly = True
            elif flag == "W":
                is_monthly = False
            else:
                is_monthly = (dd == last_of_month[(yy, mm)])
            if is_monthly:
                code  = f"{yy:02d}{mon}"
                label = f"{dd:02d} {mon} {yy:02d} (M)"
            else:
                code  = f"{yy:02d}{mm:02d}{dd:02d}"
                label = f"{dd:02d} {mon} {yy:02d} (W)"
            result[label] = code
        return result, None
    except Exception as e:
        return {}, str(e)

@st.cache_resource(ttl=24*3600)
def _fetch_mcx_expiries_from_symmaster(commodity):
    """Fallback for MCX: enumerate monthly option expiries from the public symbol master JSON.

    Per Fyers docs (https://public.fyers.in/sym_details/MCX_COM_sym_master.json),
    each key is a tradable symbol like `MCX:CRUDEOIL25DEC5500CE`. We parse out the
    {YY}{MMM} substring between the commodity name and the strike/CE/PE suffix.
    MCX commodity options are monthly only.
    """
    import re, urllib.request, json as _json
    url = "https://public.fyers.in/sym_details/MCX_COM_sym_master.json"
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            data = _json.loads(r.read().decode("utf-8"))
    except Exception as e:
        return {}, f"symbol-master fetch failed: {e}"

    pat = re.compile(rf"^MCX:{re.escape(commodity.upper())}(\d{{2}})({'|'.join(_MONTHS)})\d+(?:CE|PE)$")
    found = set()
    for key in data.keys():
        m = pat.match(str(key).upper())
        if m:
            found.add((int(m.group(1)), m.group(2)))

    if not found:
        return {}, f"no MCX:{commodity} option symbols found in MCX_COM_sym_master.json"

    sortable = sorted(found, key=lambda t: (t[0], _MONTHS.index(t[1])))
    result = {}
    for yy, mon in sortable:
        code  = f"{yy:02d}{mon}"
        label = f"-- {mon} {yy:02d} (M)"
        result[label] = code
    return result, None


def get_expiries_for(exchange, underlying):
    """Returns expiry dict — served from daily file cache; hits Fyers only once per day."""
    sym = _UNDERLYING_SYM.get(underlying.upper(), f"{exchange}:{underlying}-INDEX")

    # 1. Try today's file cache (survives server restarts)
    cached = _load_expiry_cache()
    if cached.get(sym):
        return cached[sym]

    # 2. Fetch from Fyers (cached in memory for this server process)
    try:
        token, _ = get_shared_token()
        if not token:
            return {}
        cid = get_secret("FYERS_CLIENT_ID") or CLIENT_ID
        result, err = _fetch_expiries_from_fyers(cid, token, sym)

        # 3. MCX fallback — option-chain API often returns nothing for commodities.
        # Use the public MCX symbol master file as the authoritative source.
        if not result and exchange.upper() == "MCX":
            result2, err2 = _fetch_mcx_expiries_from_symmaster(underlying)
            if result2:
                result = result2
                err = None  # success via fallback
            else:
                err = f"{err}; fallback: {err2}"

        if result:
            cached[sym] = result
            _save_expiry_cache(cached)
        else:
            st.warning(f"⚠️ Expiry fetch failed for `{sym}`: {err}")
        return result
    except Exception as e:
        st.warning(f"⚠️ Expiry fetch exception for `{sym}`: {e}")
        return {}

def expiry_selectbox(label, opts_dict, manual_key, select_key, default_manual):
    """opts_dict = {label: fyers_code}. Stores fyers_code in session state directly."""
    if opts_dict:
        codes = list(opts_dict.values())
        code_to_label = {v: k for k, v in opts_dict.items()}
        return st.selectbox(label, codes,
            format_func=lambda c: code_to_label.get(c, c),
            key=select_key)  # session state stores the CODE, displays the label
    return st.text_input(label, value=default_manual, key=manual_key)

# ─────────────────────────────────────────────
# SYMBOL BUILDER
# ─────────────────────────────────────────────

def build_symbol(exchange, underlying, expiry, option_type, strike):
    """expiry is already a Fyers code: 26MAR (monthly) or 260325 (weekly YYMMDD)."""
    ot = "CE" if option_type.upper() in ("C", "CE") else "PE"
    expiry = expiry.strip().upper()
    # Monthly: contains letters → use as-is
    if any(c.isalpha() for c in expiry):
        return f"{exchange}:{underlying}{expiry}{strike}{ot}"
    # Weekly numeric YYMMDD → YYM(no-zero)DD
    yy, mm, dd = expiry[0:2], expiry[2:4], expiry[4:6]
    return f"{exchange}:{underlying}{yy}{int(mm)}{dd}{strike}{ot}"

# ─────────────────────────────────────────────
# FETCH CANDLES
# ─────────────────────────────────────────────

def fetch_candles(fyers, symbol, interval, date_str=None):
    if date_str is None:
        date_str = date.today().strftime("%Y-%m-%d")
    response = fyers.history(data={
        "symbol": symbol, "resolution": str(interval),
        "date_format": "1", "range_from": date_str,
        "range_to": date_str, "cont_flag": "1"
    })
    if response.get("s") != "ok":
        return pd.DataFrame()
    df = pd.DataFrame(response["candles"], columns=["timestamp","open","high","low","close","volume"])
    df["datetime"] = pd.to_datetime(df["timestamp"], unit="s").dt.tz_localize("UTC").dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
    return df.drop(columns=["timestamp"]).set_index("datetime")

# ─────────────────────────────────────────────
# PAGE CONFIG
# ─────────────────────────────────────────────

st.set_page_config(page_title="NFO/BFO Spread Terminal", page_icon="📊", layout="wide", initial_sidebar_state="collapsed")

# ── CSS ───────────────────────────────────────────────────────────────
def get_theme():
    return {
        "bg":        "#f0f4f8",
        "bg2":       "#ffffff",
        "sidebar":   "#e8edf5",
        "card":      "#ffffff",
        "card_bdr":  "#cbd5e1",
        "text":      "#0f172a",
        "text2":     "#475569",
        "text3":     "#94a3b8",
        "ce":        "#dc2626",
        "pe":        "#059669",
        "diff":      "#d97706",
        "accent":    "#0284c7",
        "divider":   "#e2e8f0",
        "plot_bg":   "#f8fafc",
        "grid":      "#e2e8f0",
    }

T = get_theme()

st.markdown(f"""
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
    :root {{
        --bg: {T["bg"]};
        --bg2: {T["bg2"]};
        --sidebar: {T["sidebar"]};
        --card: {T["card"]};
        --card-bdr: {T["card_bdr"]};
        --text: {T["text"]};
        --text2: {T["text2"]};
        --text3: {T["text3"]};
        --ce: {T["ce"]};
        --pe: {T["pe"]};
        --diff: {T["diff"]};
        --accent: {T["accent"]};
        --divider: {T["divider"]};
    }}

    * {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif !important; }}
    code, .mono {{ font-family: "Courier New", monospace !important; }}

    .stApp {{
        background: var(--bg) !important;
        color: var(--text) !important;
    }}

    /* Sidebar */
    section[data-testid="stSidebar"] {{
        background: var(--sidebar) !important;
        border-right: 1px solid var(--card-bdr) !important;
    }}
    section[data-testid="stSidebar"] * {{
        color: var(--text) !important;
        
    }}
    section[data-testid="stSidebar"] .stSelectbox div[data-baseweb="select"] > div,
    section[data-testid="stSidebar"] .stTextInput input,
    section[data-testid="stSidebar"] .stNumberInput input {{
        background: var(--card) !important;
        border-color: var(--card-bdr) !important;
        color: var(--text) !important;
        border-radius: 6px !important;
    }}
    section[data-testid="stSidebar"] .stButton > button {{
        background: var(--accent) !important;
        color: white !important;
        border: none !important;
        border-radius: 8px !important;
        font-weight: 700 !important;
        font-size: 13px !important;
        letter-spacing: 0.5px !important;
        transition: all 0.2s !important;
    }}
    section[data-testid="stSidebar"] .stButton > button:hover {{
        opacity: 0.85 !important;
        transform: translateY(-1px) !important;
    }}

    /* Top nav */
    .top-nav {{
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 14px 24px;
        background: var(--bg2);
        border-bottom: 1px solid var(--card-bdr);
        border-radius: 12px;
        margin-bottom: 20px;
    }}
    .nav-brand {{
        display: flex;
        align-items: center;
        gap: 12px;
    }}
    .nav-logo {{
        width: 36px; height: 36px;
        background: linear-gradient(135deg, {T["ce"]}, {T["accent"]});
        border-radius: 8px;
        display: flex; align-items: center; justify-content: center;
        font-size: 18px;
    }}
    .nav-title {{
        font-family: "Syne", sans-serif !important;
        font-size: 18px;
        font-weight: 800;
        color: var(--text);
        letter-spacing: -0.3px;
    }}
    .nav-subtitle {{
        font-size: 11px;
        color: var(--text3);
        font-family: "Space Mono", monospace !important;
        margin-top: 1px;
    }}
    .nav-pills {{
        display: flex;
        gap: 8px;
        align-items: center;
    }}
    .nav-pill {{
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
        letter-spacing: 0.3px;
    }}
    .pill-live {{
        background: rgba(52, 211, 153, 0.15);
        color: {T["pe"]};
        border: 1px solid rgba(52, 211, 153, 0.3);
        animation: pulse 2s infinite;
    }}
    .pill-time {{
        background: var(--card);
        color: var(--text2);
        border: 1px solid var(--card-bdr);
        font-family: "Space Mono", monospace !important;
    }}
    @keyframes pulse {{
        0%, 100% {{ opacity: 1; }}
        50% {{ opacity: 0.5; }}
    }}

    /* Metric cards */
    .metrics-grid {{
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 12px;
        margin-bottom: 20px;
    }}
    @media (max-width: 768px) {{
        .metrics-grid {{ grid-template-columns: repeat(2, 1fr); }}
    }}
    .metric-card {{
        background: var(--card);
        border: 1px solid var(--card-bdr);
        border-radius: 12px;
        padding: 18px 20px;
        position: relative;
        overflow: hidden;
        transition: transform 0.15s, box-shadow 0.15s;
    }}
    .metric-card:hover {{
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(0,0,0,0.3);
    }}
    .metric-card::before {{
        content: "";
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 3px;
        border-radius: 12px 12px 0 0;
    }}
    .card-ce::before   {{ background: {T["ce"]}; }}
    .card-pe::before   {{ background: {T["pe"]}; }}
    .card-diff::before {{ background: {T["diff"]}; }}
    .card-time::before {{ background: {T["accent"]}; }}

    .metric-label {{
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        color: var(--text3);
        margin-bottom: 10px;
    }}
    .metric-value {{
        font-family: "Space Mono", monospace !important;
        font-size: 28px;
        font-weight: 700;
        line-height: 1;
        margin-bottom: 8px;
    }}
    .val-ce   {{ color: {T["ce"]}; }}
    .val-pe   {{ color: {T["pe"]}; }}
    .val-diff {{ color: {T["diff"]}; }}
    .val-time {{ color: {T["accent"]}; font-size: 22px; }}
    .metric-sub {{
        font-size: 10px;
        color: var(--text3);
        font-family: "Space Mono", monospace !important;
    }}
    .metric-badge {{
        position: absolute;
        top: 14px; right: 14px;
        font-size: 18px;
        opacity: 0.4;
    }}

    /* Sidebar sections */
    .sidebar-section {{
        background: var(--card);
        border: 1px solid var(--card-bdr);
        border-radius: 10px;
        padding: 14px;
        margin-bottom: 12px;
    }}
    .sidebar-title {{
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        color: var(--text3);
        margin-bottom: 12px;
        display: flex;
        align-items: center;
        gap: 6px;
    }}

    /* Divider */
    hr {{ border-color: var(--divider) !important; }}

    /* Expander */
    .stExpander {{
        background: var(--card) !important;
        border: 1px solid var(--card-bdr) !important;
        border-radius: 10px !important;
    }}

    /* Streamlit overrides */
    .stMarkdown p {{ color: var(--text2); }}
    .stDataFrame {{ border-radius: 10px; overflow: hidden; }}
    div[data-testid="stDecoration"] {{ display: none; }}
    
    div[data-testid="stVerticalBlock"] > div {{ gap: 0rem !important; }}
    .stSelectbox, .stTextInput, .stNumberInput {{ margin-bottom: -18px !important; }}
    .stSelectbox div[data-baseweb="select"] > div,
    .stTextInput input, .stNumberInput input {{ font-size: 13px !important; }}
    .stSelectbox label, .stTextInput label, .stNumberInput label {{ font-size: 12px !important; }}
    .stSelectbox div[data-baseweb="select"] > div,
    .stTextInput input,
    .stNumberInput input {{
        font-size: 13px !important;
    }}
    .stSelectbox label, .stTextInput label, .stNumberInput label,
    .stSelectbox [data-baseweb="select"] span {{
        font-size: 12px !important;
    }}
    
    button[data-testid="collapsedControl"] {{ display: none !important; }}
    
    section[data-testid="stSidebar"] {{ min-width: 380px !important; max-width: 380px !important; }}
    div[data-baseweb="popover"] {{ left: 0 !important; right: auto !important; }}
    div[data-baseweb="calendar"] {{ left: 0 !important; right: auto !important; }}
    
    .block-container {{ padding-top: 0.5rem !important; }}
    header[data-testid="stHeader"] {{ background: transparent !important; }}
    header[data-testid="stHeader"] > * {{ display: none !important; }}
    header[data-testid="stHeader"] {{ height: 0 !important; min-height: 0 !important; }}
</style>
""", unsafe_allow_html=True)



# ─────────────────────────────────────────────
# SIDEBAR
# ─────────────────────────────────────────────

# ─────────────────────────────────────────────
# DATE LOGIC (shared)
# ─────────────────────────────────────────────

today = date.today()
if today.weekday() == 5:
    default_date = today - pd.Timedelta(days=1)
elif today.weekday() == 6:
    default_date = today - pd.Timedelta(days=2)
else:
    default_date = today



import datetime as _dt
_now = _dt.datetime.now().strftime("%H:%M:%S")


if st.button("🔄 Refresh Token", key="refresh_token_nav", help="Clear cached token and re-authenticate"):
    _cached_generate_token.clear()
    _fetch_expiries_from_fyers.clear()
    try:
        os.remove(TOKEN_FILE)
    except FileNotFoundError:
        pass
    st.rerun()

# Show login status banner if token failed
_tok, _tok_err = get_shared_token()
if not _tok:
    if _tok_err and "Missing credentials" in _tok_err:
        st.error(
            f"❌ **Fyers credentials not configured.**\n\n"
            f"{_tok_err}\n\n"
            f"**On Streamlit Cloud:** Go to your app → ⋮ menu → **Settings → Secrets** and add:\n"
            f"```\n"
            f"FYERS_CLIENT_ID = \"XXXX-100\"\n"
            f"FYERS_SECRET_KEY = \"your_secret\"\n"
            f"FYERS_USERNAME = \"your_fy_id\"\n"
            f"FYERS_PIN = \"your_pin\"\n"
            f"FYERS_TOTP_KEY = \"your_totp_base32_key\"\n"
            f"```\n"
            f"After saving secrets, click **Refresh Token**."
        )
    elif _tok_err and "429" in _tok_err:
        st.error(f"❌ **Rate limited by Fyers.** Wait ~60 seconds then click **Refresh Token**.")
    else:
        st.error(f"❌ Login failed: {_tok_err}")
    st.stop()

st.markdown(f"""
<div class="top-nav">
    <div class="nav-brand">
        <div class="nav-logo">📊</div>
        <div>
            <div class="nav-title">NFO / BFO Spread Terminal</div>
            <div class="nav-subtitle">NFO / BFO Options Spread</div>
        </div>
    </div>
    <div class="nav-pills">
        <span class="nav-pill pill-live">● LIVE</span>
        <span class="nav-pill pill-time">{_now} IST</span>
    </div>
</div>
""", unsafe_allow_html=True)

st.markdown("""
<style>
div[data-testid="stMainBlockContainer"] > div > div > div:nth-child(1) button {
    position: fixed !important;
    top: 10px !important;
    right: 200px !important;
    z-index: 9999 !important;
    background: rgba(2,132,199,0.15) !important;
    border: 1px solid rgba(2,132,199,0.4) !important;
    color: #0284c7 !important;
    border-radius: 20px !important;
    padding: 3px 12px !important;
    font-size: 11px !important;
    font-weight: 600 !important;
}
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────
# FETCH LIVE DATA
# ─────────────────────────────────────────────

def fetch_live_data():
    fyers = get_fyers_client()
    if fyers is None:
        return pd.DataFrame()

    with st.spinner("Fetching option & spot prices from Fyers..."):
        df_sx_ce   = fetch_candles(fyers, sym_sx_ce, candle_interval, date_str)
        df_sx_pe   = fetch_candles(fyers, sym_sx_pe, candle_interval, date_str)
        df_nf_ce   = fetch_candles(fyers, sym_nf_ce, candle_interval, date_str)
        df_nf_pe   = fetch_candles(fyers, sym_nf_pe, candle_interval, date_str)
        df_sx_spot = fetch_candles(fyers, "BSE:SENSEX-INDEX", candle_interval, date_str)
        if df_sx_spot.empty:
            df_sx_spot = fetch_candles(fyers, "BSE:SENSEX", candle_interval, date_str)
        df_nf_spot = fetch_candles(fyers, "NSE:NIFTY50-INDEX", candle_interval, date_str)
        if df_nf_spot.empty:
            df_nf_spot = fetch_candles(fyers, "NSE:NIFTY50", candle_interval, date_str)
        if df_sx_spot.empty or df_nf_spot.empty:
            st.session_state["spot_debug"] = f"SENSEX spot={len(df_sx_spot)} rows | NIFTY spot={len(df_nf_spot)} rows"
        else:
            st.session_state["spot_debug"] = ""

    if any(df.empty for df in [df_sx_ce, df_sx_pe, df_nf_ce, df_nf_pe]):
        st.warning(f"⚠️ One or more symbols returned no data. Built: `{sym_sx_ce}` | `{sym_sx_pe}` | `{sym_nf_ce}` | `{sym_nf_pe}`")
        return pd.DataFrame()

    df_sx_ce   = df_sx_ce[~df_sx_ce.index.duplicated(keep="last")]
    df_sx_pe   = df_sx_pe[~df_sx_pe.index.duplicated(keep="last")]
    df_nf_ce   = df_nf_ce[~df_nf_ce.index.duplicated(keep="last")]
    df_nf_pe   = df_nf_pe[~df_nf_pe.index.duplicated(keep="last")]
    df_sx_spot = df_sx_spot[~df_sx_spot.index.duplicated(keep="last")]
    df_nf_spot = df_nf_spot[~df_nf_spot.index.duplicated(keep="last")]

    common_idx = df_sx_ce.index.intersection(df_sx_pe.index).intersection(df_nf_ce.index).intersection(df_nf_pe.index)
    df = pd.DataFrame({
        "sensex_ce": df_sx_ce["close"].reindex(common_idx),
        "sensex_pe": df_sx_pe["close"].reindex(common_idx),
        "nifty_ce" : df_nf_ce["close"].reindex(common_idx),
        "nifty_pe" : df_nf_pe["close"].reindex(common_idx),
    }).dropna()

    # Synthetic Future = Spot + CE - PE
    if not df_sx_spot.empty and not df_nf_spot.empty:
        df["sensex_spot"] = df_sx_spot["close"].reindex(df.index, method="ffill")
        df["nifty_spot"]  = df_nf_spot["close"].reindex(df.index, method="ffill")
        df["synth_sensex"] = df["sensex_spot"] + df["sensex_ce"] - df["sensex_pe"]
        df["synth_nifty"]  = df["nifty_spot"]  + df["nifty_ce"]  - df["nifty_pe"]
        df["synth_ratio"]  = df["synth_sensex"] / df["synth_nifty"]

    df["ce_spread"] = df["sensex_ce"] - (df["nifty_ce"] * multiplier)
    df["pe_spread"] = df["sensex_pe"] - (df["nifty_pe"] * multiplier)
    df["diff"]      = df["ce_spread"] + df["pe_spread"]
    return df

# ─────────────────────────────────────────────
# SESSION STATE
# ─────────────────────────────────────────────

if "df" not in st.session_state:
    st.session_state.df = pd.DataFrame()
if "df_custom" not in st.session_state:
    st.session_state.df_custom = pd.DataFrame()
if "df_bfly8" not in st.session_state:
    st.session_state.df_bfly8 = pd.DataFrame()
if "df_mcx" not in st.session_state:
    st.session_state.df_mcx = pd.DataFrame()

# ─────────────────────────────────────────────
# TABS
# ─────────────────────────────────────────────

tab1, tab2, tab3, tab4, tab5 = st.tabs(["📊 Spread Dashboard", "🧮 Butterfly", "📐 IV Analysis","🦋 Butterfly Straddle", "🔶 MCX Spread"])

# ─────────────────────────────────────────────
# TAB 2 — CUSTOM 4-LEG BUILDER
# ─────────────────────────────────────────────

with tab2:
    st.markdown("<div style='font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#64748b;margin-bottom:8px;'>Configure 4 Legs</div>", unsafe_allow_html=True)

    UNDERLYINGS = ["SENSEX", "BANKEX", "NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY"]
    leg_colors  = ["#f87171", "#34d399", "#60a5fa", "#fbbf24"]
    leg_labels  = ["Leg 1", "Leg 2", "Leg 3", "Leg 4"]
    leg_configs = []

    # ── Next Tuesday (NSE) and next Thursday (BSE) expiry ──
    def next_weekday_str(weekday):
        d = date.today()
        days_ahead = weekday - d.weekday()
        if days_ahead <= 0:
            days_ahead += 7
        return (d + pd.Timedelta(days=days_ahead)).strftime("%y%m%d")

    nse_exp = next_weekday_str(1)  # Tuesday
    bse_exp = next_weekday_str(3)  # Thursday

    LEG_DEFAULTS = [
        ("BSE", "SENSEX",  nse_exp, 80000, "CE", 1.0),
        ("NSE", "NIFTY", bse_exp, 24200, "CE", 3.3),
        ("BSE", "SENSEX", bse_exp, 80000, "CE", 1.0),
        ("NSE", "NIFTY",  nse_exp, 24200, "CE", 3.3),
    ]

    if "c_defaults_set" not in st.session_state:
        for i, (ex, un, ep, st_, ot, mu) in enumerate(LEG_DEFAULTS):
            st.session_state[f"c_exch_{i}"]  = ex
            st.session_state[f"c_under_{i}"] = un
            st.session_state[f"c_exp_{i}"]   = ep
            st.session_state[f"c_str_{i}"]   = float(st_)
            st.session_state[f"c_opt_{i}"]   = ot
            st.session_state[f"c_lots_{i}"]  = mu
        st.session_state["c_defaults_set"] = True

    c_row = st.columns([1.2, 1, 1, 1, 1.5])
    with c_row[0]: custom_date     = st.date_input("Date",       value=default_date,           key="c_date")
    with c_row[1]: custom_interval = st.selectbox("Interval",    [1,3,5,10,15,30,60], index=2, key="c_interval")
    with c_row[2]: c_auto          = st.checkbox("Auto Refresh", value=False,                  key="c_auto_refresh")
    with c_row[3]: c_secs          = st.slider("Sec", 5, 60, 10,                               key="c_refresh_secs")
    with c_row[4]: custom_fetch    = st.button("⟳  FETCH 4-LEG DATA", type="primary", use_container_width=True, key="c_fetch")

    # All 4 legs on 2 rows (2 legs per row), same style as Tab 1
    for row_idx in range(2):
        legs_in_row = [row_idx * 2, row_idx * 2 + 1]
        cols = st.columns([0.25, 0.5, 0.8, 0.8, 0.65, 0.65, 0.6, 0.15,
                           0.25, 0.5, 0.8, 0.8, 0.65, 0.65, 0.6])
        for j, i in enumerate(legs_in_row):
            d_exch, d_under, d_exp, d_str, d_opt, d_mult = LEG_DEFAULTS[i]
            exch_opts = ["NSE","BSE"] if d_exch == "NSE" else ["BSE","NSE"]
            und_opts  = [d_under] + [u for u in UNDERLYINGS if u != d_under]
            off = j * 8  # column offset for second leg
            cols[off].markdown(f"<div style='padding-top:28px;font-size:10px;font-weight:700;color:{leg_colors[i]};'>{leg_labels[i].upper()}</div>", unsafe_allow_html=True)
            with cols[off+1]: exch  = st.selectbox("Exchange",   exch_opts, key=f"c_exch_{i}")
            with cols[off+2]: under = st.selectbox("Underlying", und_opts,  key=f"c_under_{i}")
            _exp_opts = get_expiries_for(exch, under)
            with cols[off+3]: expiry   = expiry_selectbox("Expiry", _exp_opts, f"c_exp_man_{i}", f"c_exp_sel_{i}", d_exp)
            with cols[off+4]: strike   = st.number_input("Strike",   step=100,              key=f"c_str_{i}")
            with cols[off+5]: opt_type = st.selectbox("CE/PE",      ["CE","PE"],            key=f"c_opt_{i}")
            with cols[off+6]: mult     = st.number_input("Mult",     min_value=0.1, step=0.1, key=f"c_lots_{i}")
            if j == 0:
                cols[7].markdown("<div style='padding-top:28px;font-size:10px;color:#e2e8f0;text-align:center;'>│</div>", unsafe_allow_html=True)
            leg_configs.append({"exchange": exch, "underlying": under, "expiry": expiry,
                                "strike": int(strike), "opt_type": opt_type, "lots": mult})

    

    custom_date_str = custom_date.strftime("%Y-%m-%d")

    L = leg_configs
    def leg_name(i): return f"{L[i]['lots']}×{L[i]['underlying']} {L[i]['opt_type']}"
    st.markdown(f"""
    <div style='font-size:11px;color:#64748b;margin:4px 0 8px 0;font-family:monospace;'>
        Chart 1: &nbsp;<span style='color:#f87171'>{leg_name(0)}</span> − <span style='color:#34d399'>{leg_name(1)}</span>
        &nbsp;&nbsp;|&nbsp;&nbsp;
        <span style='color:#60a5fa'>{leg_name(2)}</span> − <span style='color:#fbbf24'>{leg_name(3)}</span>
        &nbsp;&nbsp;&nbsp;&nbsp;
        Chart 2: &nbsp;(Leg1−Leg2) + (Leg3−Leg4)
    </div>
    """, unsafe_allow_html=True)

    if custom_fetch:
        fyers = get_fyers_client()
        if fyers is None:
            st.error("Not connected to Fyers.")
        else:
            raw_series = []
            ok = True
            with st.spinner("Fetching 4-leg data..."):
                for i, leg in enumerate(leg_configs):
                    sym = build_symbol(leg["exchange"], leg["underlying"], leg["expiry"], leg["opt_type"][0], leg["strike"])
                    df_leg = fetch_candles(fyers, sym, custom_interval, custom_date_str)
                    if df_leg.empty:
                        st.warning(f"⚠️ {leg_labels[i]}: No data for `{sym}`")
                        ok = False
                        break
                    df_leg = df_leg[~df_leg.index.duplicated(keep="last")]
                    raw_series.append(df_leg["close"] * leg["lots"])

            if ok and len(raw_series) == 4:
                base_idx = raw_series[0].index
                s = [sr.reindex(base_idx, method="ffill").fillna(0) for sr in raw_series]
                spread12 = s[0] - s[1]
                spread34 = s[2] - s[3]
                combined = spread12 + spread34
                st.session_state.df_custom = pd.DataFrame({
                    "line1": spread12,
                    "line2": spread34,
                    "combined": combined,
                })

    df_custom = st.session_state.df_custom

    if not df_custom.empty:
        _s12  = df_custom['spread12'].iloc[-1]
        _s34  = df_custom['spread34'].iloc[-1]
        _comb = df_custom['combined'].iloc[-1]
        _s12_d  = _s12  - df_custom['spread12'].iloc[-2] if len(df_custom) > 1 else 0
        _s34_d  = _s34  - df_custom['spread34'].iloc[-2] if len(df_custom) > 1 else 0
        _comb_d = _comb - df_custom['combined'].iloc[-2] if len(df_custom) > 1 else 0
        _updated = df_custom.index[-1].strftime("%H:%M:%S")

        def _darrow(v):
            arrow = "▲" if v >= 0 else "▼"
            color = "#f87171" if v >= 0 else "#34d399"
            return f"<span style='color:{color};font-size:11px;'>{arrow} {abs(v):.2f}</span>"

        st.markdown(f"""
        <div class="metrics-grid">
            <div class="metric-card card-ce">
                <div class="metric-badge">📊</div>
                <div class="metric-label">LEG1−LEG2+LEG3−LEG4</div>
                <div class="metric-value val-ce">{_s12:+.1f}</div>
                <div class="metric-sub">Spread &nbsp; {_darrow(_s12_d)}</div>
            </div>
            <div class="metric-card card-pe">
                <div class="metric-badge">📊</div>
                <div class="metric-label">LEG5−LEG6+LEG7−LEG8</div>
                <div class="metric-value val-pe">{_s34:+.1f}</div>
                <div class="metric-sub">Spread &nbsp; {_darrow(_s34_d)}</div>
            </div>
            <div class="metric-card card-diff">
                <div class="metric-badge">⚖️</div>
                <div class="metric-label">4 LEG TOTAL</div>
                <div class="metric-value val-diff">{_comb:+.1f}</div>
                <div class="metric-sub">(Leg1−Leg2) + (Leg3−Leg4) &nbsp; {_darrow(_comb_d)}</div>
            </div>
            <div class="metric-card card-time">
                <div class="metric-badge">🕐</div>
                <div class="metric-label">LAST UPDATE</div>
                <div class="metric-value val-time">{_updated}</div>
                <div class="metric-sub">{len(df_custom)} candles</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        def make_hlines(fig, series, colors):
            h, l = series.max(), series.min()
            fig.add_hline(y=0, line_dash="dash", line_color="#444")
            fig.add_hline(y=h, line_dash="dot", line_color=colors[0], line_width=1,
                annotation_text=f"H: {h:.0f}", annotation_position="right",
                annotation_font=dict(color=colors[0], size=10))
            fig.add_hline(y=l, line_dash="dot", line_color=colors[1], line_width=1,
                annotation_text=f"L: {l:.0f}", annotation_position="right",
                annotation_font=dict(color=colors[1], size=10))

        def chart_layout(fig, title, height=380):
            fig.update_layout(
                title=dict(text=title, font=dict(size=12, color=T["text2"]), x=0),
                height=height,
                plot_bgcolor=T["plot_bg"], paper_bgcolor=T["plot_bg"],
                font=dict(color=T["text2"]),
                hovermode="x unified",
                margin=dict(l=10, r=10, t=40, b=10),
                legend=dict(bgcolor=T["card"], bordercolor=T["card_bdr"], borderwidth=1,
                    orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                xaxis=dict(gridcolor=T["grid"], tickfont=dict(size=10),
                    showspikes=True, spikemode="across", spikecolor=T["text3"], spikethickness=1, spikedash="dot"),
                yaxis=dict(gridcolor=T["grid"], title="Value (₹)", tickfont=dict(size=10),
                    showspikes=True, spikemode="across", spikecolor=T["text3"], spikethickness=1, spikedash="dot"),
                hoverlabel=dict(bgcolor=T["card"], bordercolor=T["card_bdr"], font=dict(color=T["text"])),
            )

        fig1 = go.Figure()
        fig1.add_trace(go.Scatter(x=df_custom.index, y=df_custom["spread12"],
            name="Leg1−Leg2+Leg3−Leg4", line=dict(color="red", width=2),
            hovertemplate="%{x|%H:%M}<br>Leg1−Leg2: %{y:.2f}<extra></extra>"))
        fig1.add_trace(go.Scatter(x=df_custom.index, y=df_custom["spread34"],
            name="Leg5−Leg6+Leg7−Leg8", line=dict(color="green", width=2),
            hovertemplate="%{x|%H:%M}<br>Leg3−Leg4: %{y:.2f}<extra></extra>"))
        make_hlines(fig1, df_custom["spread12"], ["#f87171", "#f87171"])
        chart_layout(fig1, "Spread Chart — Leg1−Leg2  &  Leg3−Leg4")
        st.plotly_chart(fig1, use_container_width=True)

        fig2 = go.Figure()
        fig2.add_trace(go.Scatter(x=df_custom.index, y=df_custom["combined"],
            name="Combined (Leg1−Leg2) + (Leg3−Leg4)",
            line=dict(color="#818cf8", width=2.5),
            fill="tozeroy", fillcolor="rgba(129,140,248,0.08)",
            hovertemplate="%{x|%H:%M}<br>Combined: %{y:.2f}<extra></extra>"))
        make_hlines(fig2, df_custom["combined"], ["#34d399", "#f87171"])
        chart_layout(fig2, "Combined Chart — (Leg1−Leg2) + (Leg3−Leg4)")
        st.plotly_chart(fig2, use_container_width=True)
    else:
        st.info("👆 Configure your 4 legs above and click **Fetch 4-Leg Data**.")

with tab4:
    st.markdown("<div style='font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#64748b;margin-bottom:8px;'>Configure 8 Legs</div>", unsafe_allow_html=True)

    UNDERLYINGS = ["SENSEX", "BANKEX", "NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY"]
    leg_colors  = ["#f87171","#34d399","#60a5fa","#fbbf24","#f472b6","#22d3ee","#a78bfa","#fb923c"]
    leg_labels  = ["Leg 1","Leg 2","Leg 3","Leg 4","Leg 5","Leg 6","Leg 7","Leg 8"]
    leg_configs = []

    # ── Next Tuesday (NSE) and next Thursday (BSE) expiry ──
    def next_weekday_str(weekday):
        d = date.today()
        days_ahead = weekday - d.weekday()
        if days_ahead <= 0:
            days_ahead += 7
        return (d + pd.Timedelta(days=days_ahead)).strftime("%y%m%d")

    nse_exp = next_weekday_str(1)  # Tuesday
    bse_exp = next_weekday_str(3)  # Thursday

    LEG_DEFAULTS = [
        ("BSE", "SENSEX",  nse_exp, 80000, "CE", 1.0),
        ("NSE", "NIFTY", bse_exp, 24200, "CE", 3.3),
        ("BSE", "SENSEX", bse_exp, 80000, "CE", 1.0),
        ("NSE", "NIFTY",  nse_exp, 24200, "CE", 3.3),
        ("BSE", "SENSEX",  nse_exp, 80000, "CE", 1.0),
        ("NSE", "NIFTY", bse_exp, 24200, "CE", 3.3),
        ("BSE", "SENSEX", bse_exp, 80000, "CE", 1.0),
        ("NSE", "NIFTY",  nse_exp, 24200, "CE", 3.3),
    ]

    if "b8_defaults_set" not in st.session_state:
        for i, (ex, un, ep, st_, ot, mu) in enumerate(LEG_DEFAULTS):
            st.session_state[f"b8_exch_{i}"]  = ex
            st.session_state[f"b8_under_{i}"] = un
            st.session_state[f"b8_exp_{i}"]   = ep
            st.session_state[f"b8_str_{i}"]   = float(st_)
            st.session_state[f"b8_opt_{i}"]   = ot
            st.session_state[f"b8_lots_{i}"]  = mu
        st.session_state["b8_defaults_set"] = True

    b8_row = st.columns([1.2, 1, 1, 1, 1.5])
    with b8_row[0]: custom_date     = st.date_input("Date",       value=default_date,           key="b8_date")
    with b8_row[1]: custom_interval = st.selectbox("Interval",    [1,3,5,10,15,30,60], index=2, key="b8_interval")
    with b8_row[2]: b8_auto          = st.checkbox("Auto Refresh", value=False,                  key="b8_auto_refresh")
    with b8_row[3]: b8_secs          = st.slider("Sec", 5, 60, 10,                               key="b8_refresh_secs")
    with b8_row[4]: custom_fetch    = st.button("⟳  FETCH 4-LEG DATA", type="primary", use_container_width=True, key="b8_fetch")

    # All 4 legs on 2 rows (2 legs per row), same style as Tab 1
    for row_idx in range(4):
        legs_in_row = [row_idx * 2, row_idx * 2 + 1]
        cols = st.columns([0.25, 0.5, 0.8, 0.8, 0.65, 0.65, 0.6, 0.15,
                           0.25, 0.5, 0.8, 0.8, 0.65, 0.65, 0.6])
        for j, i in enumerate(legs_in_row):
            d_exch, d_under, d_exp, d_str, d_opt, d_mult = LEG_DEFAULTS[i]
            exch_opts = ["NSE","BSE"] if d_exch == "NSE" else ["BSE","NSE"]
            und_opts  = [d_under] + [u for u in UNDERLYINGS if u != d_under]
            off = j * 8  # column offset for second leg
            cols[off].markdown(f"<div style='padding-top:28px;font-size:10px;font-weight:700;color:{leg_colors[i]};'>{leg_labels[i].upper()}</div>", unsafe_allow_html=True)
            with cols[off+1]: exch  = st.selectbox("Exchange",   exch_opts, key=f"b8_exch_{i}")
            with cols[off+2]: under = st.selectbox("Underlying", und_opts,  key=f"b8_under_{i}")
            _exp_opts = get_expiries_for(exch, under)
            with cols[off+3]: expiry   = expiry_selectbox("Expiry", _exp_opts, f"b8_exp_man_{i}", f"b8_exp_sel_{i}", d_exp)
            with cols[off+4]: strike   = st.number_input("Strike",   step=100,              key=f"b8_str_{i}")
            with cols[off+5]: opt_type = st.selectbox("CE/PE",      ["CE","PE"],            key=f"b8_opt_{i}")
            with cols[off+6]: mult     = st.number_input("Mult",     min_value=0.1, step=0.1, key=f"b8_lots_{i}")
            if j == 0:
                cols[7].markdown("<div style='padding-top:28px;font-size:10px;color:#e2e8f0;text-align:center;'>│</div>", unsafe_allow_html=True)
            leg_configs.append({"exchange": exch, "underlying": under, "expiry": expiry,
                                "strike": int(strike), "opt_type": opt_type, "lots": mult})

    

    custom_date_str = custom_date.strftime("%Y-%m-%d")

    L = leg_configs
    def leg_name(i): return f"{L[i]['lots']}×{L[i]['underlying']} {L[i]['opt_type']}"
    st.markdown(f"""
    <div style='font-size:11px;color:#64748b;margin:4px 0 8px 0;font-family:monospace;'>
        Chart 1: &nbsp;<span style='color:#f87171'>{leg_name(0)}</span> − <span style='color:#34d399'>{leg_name(1)}</span>
        &nbsp;&nbsp;|&nbsp;&nbsp;
        <span style='color:#60a5fa'>{leg_name(2)}</span> − <span style='color:#fbbf24'>{leg_name(3)}</span>
        &nbsp;&nbsp;&nbsp;&nbsp;
        Chart 2: &nbsp;(Leg1−Leg2) + (Leg3−Leg4)
    </div>
    """, unsafe_allow_html=True)

    if custom_fetch:
        fyers = get_fyers_client()
        if fyers is None:
            st.error("Not connected to Fyers.")
        else:
            raw_series = []
            ok = True
            with st.spinner("Fetching 8-leg data..."):
                for i, leg in enumerate(leg_configs):
                    sym = build_symbol(leg["exchange"], leg["underlying"], leg["expiry"], leg["opt_type"][0], leg["strike"])
                    df_leg = fetch_candles(fyers, sym, custom_interval, custom_date_str)
                    if df_leg.empty:
                        st.warning(f"⚠️ {leg_labels[i]}: No data for `{sym}`")
                        ok = False
                        break
                    df_leg = df_leg[~df_leg.index.duplicated(keep="last")]
                    raw_series.append(df_leg["close"] * leg["lots"])

            if ok and len(raw_series) == 8:
                base_idx = raw_series[0].index
                s = [sr.reindex(base_idx, method="ffill").fillna(0) for sr in raw_series]
                spread12 = (s[0]-s[1]) + (s[2]-s[3])
                spread34 = (s[4]-s[5]) + (s[6]-s[7])
                combined = spread12 + spread34
                st.session_state.df_bfly8 = pd.DataFrame({
                    "line1": spread12,
                    "line2": spread34,
                    "combined": combined,
                })

    df_bfly8 = st.session_state.df_bfly8

    if not df_bfly8.empty:
        _s12  = df_bfly8['line1'].iloc[-1]
        _s34  = df_bfly8['line2'].iloc[-1]
        _comb = df_bfly8['combined'].iloc[-1]
        _s12_d  = _s12  - df_bfly8['line1'].iloc[-2] if len(df_bfly8) > 1 else 0
        _s34_d  = _s34  - df_bfly8['line2'].iloc[-2] if len(df_bfly8) > 1 else 0
        _comb_d = _comb - df_bfly8['combined'].iloc[-2] if len(df_bfly8) > 1 else 0
        _updated = df_bfly8.index[-1].strftime("%H:%M:%S")

        def _darrow(v):
            arrow = "▲" if v >= 0 else "▼"
            color = "#f87171" if v >= 0 else "#34d399"
            return f"<span style='color:{color};font-size:11px;'>{arrow} {abs(v):.2f}</span>"

        st.markdown(f"""
        <div class="metrics-grid">
            <div class="metric-card card-ce">
                <div class="metric-badge">📊</div>
                <div class="metric-label">LEG1−LEG2+LEG3−LEG4</div>
                <div class="metric-value val-ce">{_s12:+.1f}</div>
                <div class="metric-sub">Spread &nbsp; {_darrow(_s12_d)}</div>
            </div>
            <div class="metric-card card-pe">
                <div class="metric-badge">📊</div>
                <div class="metric-label">LEG5−LEG6+LEG7−LEG8</div>
                <div class="metric-value val-pe">{_s34:+.1f}</div>
                <div class="metric-sub">Spread &nbsp; {_darrow(_s34_d)}</div>
            </div>
            <div class="metric-card card-diff">
                <div class="metric-badge">⚖️</div>
                <div class="metric-label">4 LEG TOTAL</div>
                <div class="metric-value val-diff">{_comb:+.1f}</div>
                <div class="metric-sub">(Leg1−Leg2) + (Leg3−Leg4) &nbsp; {_darrow(_comb_d)}</div>
            </div>
            <div class="metric-card card-time">
                <div class="metric-badge">🕐</div>
                <div class="metric-label">LAST UPDATE</div>
                <div class="metric-value val-time">{_updated}</div>
                <div class="metric-sub">{len(df_bfly8)} candles</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        def make_hlines(fig, series, colors):
            h, l = series.max(), series.min()
            fig.add_hline(y=0, line_dash="dash", line_color="#444")
            fig.add_hline(y=h, line_dash="dot", line_color=colors[0], line_width=1,
                annotation_text=f"H: {h:.0f}", annotation_position="right",
                annotation_font=dict(color=colors[0], size=10))
            fig.add_hline(y=l, line_dash="dot", line_color=colors[1], line_width=1,
                annotation_text=f"L: {l:.0f}", annotation_position="right",
                annotation_font=dict(color=colors[1], size=10))

        def chart_layout(fig, title, height=380):
            fig.update_layout(
                title=dict(text=title, font=dict(size=12, color=T["text2"]), x=0),
                height=height,
                plot_bgcolor=T["plot_bg"], paper_bgcolor=T["plot_bg"],
                font=dict(color=T["text2"]),
                hovermode="x unified",
                margin=dict(l=10, r=10, t=40, b=10),
                legend=dict(bgcolor=T["card"], bordercolor=T["card_bdr"], borderwidth=1,
                    orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                xaxis=dict(gridcolor=T["grid"], tickfont=dict(size=10),
                    showspikes=True, spikemode="across", spikecolor=T["text3"], spikethickness=1, spikedash="dot"),
                yaxis=dict(gridcolor=T["grid"], title="Value (₹)", tickfont=dict(size=10),
                    showspikes=True, spikemode="across", spikecolor=T["text3"], spikethickness=1, spikedash="dot"),
                hoverlabel=dict(bgcolor=T["card"], bordercolor=T["card_bdr"], font=dict(color=T["text"])),
            )

        fig1 = go.Figure()
        fig1.add_trace(go.Scatter(x=df_bfly8.index, y=df_bfly8["line1"],
            name="Leg1−Leg2+Leg3−Leg4", line=dict(color="red", width=2),
            hovertemplate="%{x|%H:%M}<br>Leg1−Leg2: %{y:.2f}<extra></extra>"))
        fig1.add_trace(go.Scatter(x=df_bfly8.index, y=df_bfly8["line2"],
            name="Leg5−Leg6+Leg7−Leg8", line=dict(color="green", width=2),
            hovertemplate="%{x|%H:%M}<br>Leg3−Leg4: %{y:.2f}<extra></extra>"))
        make_hlines(fig1, df_bfly8["line1"], ["#f87171", "#f87171"])
        chart_layout(fig1, "Spread Chart — Line1 vs Line2")
        st.plotly_chart(fig1, use_container_width=True)

        fig2 = go.Figure()
        fig2.add_trace(go.Scatter(x=df_bfly8.index, y=df_bfly8["combined"],
            name="Combined (Leg1−Leg2) + (Leg3−Leg4)",
            line=dict(color="#818cf8", width=2.5),
            fill="tozeroy", fillcolor="rgba(129,140,248,0.08)",
            hovertemplate="%{x|%H:%M}<br>Combined: %{y:.2f}<extra></extra>"))
        make_hlines(fig2, df_bfly8["combined"], ["#34d399", "#f87171"])
        chart_layout(fig2, "Combined Chart — (Leg1−Leg2) + (Leg3−Leg4)")
        st.plotly_chart(fig2, use_container_width=True)
    else:
        st.info("👆 Configure your 4 legs above and click **Fetch 8-Leg Data**.")


# ─────────────────────────────────────────────
# TAB 1 — SPREAD DASHBOARD
# ─────────────────────────────────────────────

with tab1:
    # ── Controls ──
    st.markdown("<div style='font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#64748b;margin-bottom:4px;'>⚙ Settings</div>", unsafe_allow_html=True)
    r0 = st.columns([1.2, 1, 1, 1, 1, 1, 1, 1.5])
    with r0[0]: selected_date  = st.date_input("Date", value=default_date, key="date_inp")
    with r0[1]: multiplier     = st.number_input("Ratio", value=3.3, step=0.1, min_value=0.1, key="mult")
    with r0[2]: candle_interval= st.selectbox("Interval (min)", [1, 3, 5, 10, 15, 30, 60], index=2, key="interval")
    with r0[3]: show_diff      = st.checkbox("4-Leg Chart", value=True, key="show_diff")
    with r0[4]: auto_refresh   = st.checkbox("Auto Refresh", value=True, key="auto_ref")
    with r0[5]: refresh_secs   = st.slider("Refresh (sec)", 5, 60, REFRESH_SECONDS, key="ref_sec")
    with r0[6]: st.markdown("<div style='height:28px'></div>", unsafe_allow_html=True)
    with r0[7]: fetch_btn      = st.button("⟳  FETCH DATA", use_container_width=True, type="primary", key="fetch_btn")

    date_str = selected_date.strftime("%Y-%m-%d")

    # Both legs on one row: L1-label | exch | under | ce-exp | pe-exp | ce-str | pe-str | gap | L2-label | exch | under | ce-exp | pe-exp | ce-str | pe-str
    legs_row = st.columns([0.25, 0.5, 0.8, 0.8, 0.8, 0.65, 0.65, 0.15, 0.25, 0.5, 0.8, 0.8, 0.8, 0.65, 0.65])
    legs_row[0].markdown("<div style='padding-top:28px;font-size:10px;font-weight:700;letter-spacing:1px;color:#dc2626;'>LEG 1</div>", unsafe_allow_html=True)
    with legs_row[1]:  sensex_exchange   = st.selectbox("Exchange",   ["BSE","NSE"],                                                           index=0, key="sx_exch")
    with legs_row[2]:  sensex_underlying = st.selectbox("Underlying",  ["SENSEX","BANKEX","NIFTY","BANKNIFTY","FINNIFTY","MIDCPNIFTY"],         index=0, key="sx_under")
    _sx_opts = get_expiries_for(sensex_exchange, sensex_underlying)
    with legs_row[3]:  sensex_ce_expiry  = expiry_selectbox("CE Expiry", _sx_opts, "sx_ce_man", "sx_ce_sel", "260312")
    with legs_row[4]:  sensex_pe_expiry  = expiry_selectbox("PE Expiry", _sx_opts, "sx_pe_man", "sx_pe_sel", "260312")
    with legs_row[5]:  sensex_ce_strike  = st.number_input("CE Strike", value=80000, step=100, key="sx_ce_str")
    with legs_row[6]:  sensex_pe_strike  = st.number_input("PE Strike", value=80000, step=100, key="sx_pe_str")
    legs_row[7].markdown("<div style='padding-top:28px;font-size:10px;color:#e2e8f0;text-align:center;'>│</div>", unsafe_allow_html=True)
    legs_row[8].markdown("<div style='padding-top:28px;font-size:10px;font-weight:700;letter-spacing:1px;color:#0284c7;'>LEG 2</div>", unsafe_allow_html=True)
    with legs_row[9]:  nifty_exchange    = st.selectbox("Exchange",   ["NSE","BSE"],                                                           index=0, key="nf_exch")
    with legs_row[10]: nifty_underlying  = st.selectbox("Underlying",  ["NIFTY","BANKNIFTY","FINNIFTY","MIDCPNIFTY","SENSEX","BANKEX"],         index=0, key="nf_under")
    _nf_opts = get_expiries_for(nifty_exchange, nifty_underlying)
    with legs_row[11]: nifty_ce_expiry   = expiry_selectbox("CE Expiry", _nf_opts, "nf_ce_man", "nf_ce_sel", "260310")
    with legs_row[12]: nifty_pe_expiry   = expiry_selectbox("PE Expiry", _nf_opts, "nf_pe_man", "nf_pe_sel", "260310")
    with legs_row[13]: nifty_ce_strike   = st.number_input("CE Strike", value=24800, step=50, key="nf_ce_str")
    with legs_row[14]: nifty_pe_strike   = st.number_input("PE Strike", value=24800, step=50, key="nf_pe_str")

    st.divider()

    # ── Symbols ──
    sym_sx_ce = build_symbol(sensex_exchange, sensex_underlying, sensex_ce_expiry, "C", int(sensex_ce_strike))
    sym_sx_pe = build_symbol(sensex_exchange, sensex_underlying, sensex_pe_expiry, "P", int(sensex_pe_strike))
    sym_nf_ce = build_symbol(nifty_exchange,  nifty_underlying,  nifty_ce_expiry,  "C", int(nifty_ce_strike))
    sym_nf_pe = build_symbol(nifty_exchange,  nifty_underlying,  nifty_pe_expiry,  "P", int(nifty_pe_strike))

    if fetch_btn or st.session_state.df.empty:
        st.session_state.df = fetch_live_data()
    df = st.session_state.df

    if df.empty:
        st.info("👆 Set your options above and click **Fetch Data**.")
    else:
        latest   = df.iloc[-1]
        ce_val   = latest["ce_spread"]
        pe_val   = latest["pe_spread"]
        diff_val = latest["diff"]
        updated  = df.index[-1].strftime("%H:%M:%S")
        is_today = date_str == date.today().strftime("%Y-%m-%d")

        ce_delta  = ce_val  - df["ce_spread"].iloc[-2]  if len(df) > 1 else 0
        pe_delta  = pe_val  - df["pe_spread"].iloc[-2]  if len(df) > 1 else 0
        diff_delta= diff_val- df["diff"].iloc[-2]        if len(df) > 1 else 0

        def delta_html(v):
            arrow = "▲" if v >= 0 else "▼"
            color = "#f87171" if v >= 0 else "#34d399"
            return f"<span style='color:{color};font-size:11px;font-family:Space Mono'>{arrow} {abs(v):.2f}</span>"

        synth_val = f"{latest['synth_ratio']:.4f}" if "synth_ratio" in df.columns and pd.notna(latest.get("synth_ratio")) else "N/A"

        st.markdown(f"""
        <div class="metrics-grid">
            <div class="metric-card card-ce">
                <div class="metric-badge">📈</div>
                <div class="metric-label">CE SPREAD</div>
                <div class="metric-value val-ce">{ce_val:+.1f}</div>
                <div class="metric-sub">{sensex_underlying} CE − {nifty_underlying} CE &times;{multiplier} &nbsp; {delta_html(ce_delta)}</div>
            </div>
            <div class="metric-card card-pe">
                <div class="metric-badge">📉</div>
                <div class="metric-label">PE SPREAD</div>
                <div class="metric-value val-pe">{pe_val:+.1f}</div>
                <div class="metric-sub">{sensex_underlying} PE − {nifty_underlying} PE &times;{multiplier} &nbsp; {delta_html(pe_delta)}</div>
            </div>
            <div class="metric-card card-diff">
                <div class="metric-badge">⚖️</div>
                <div class="metric-label">4 LEG TOTAL</div>
                <div class="metric-value val-diff">{diff_val:+.1f}</div>
                <div class="metric-sub">CE + PE combined &nbsp; {delta_html(diff_delta)}</div>
            </div>
            <div class="metric-card card-time">
                <div class="metric-badge">🔢</div>
                <div class="metric-label">SYNTHETIC FUT - MULTIPLIER</div>
                <div class="metric-value val-time">{synth_val}</div>
                <div class="metric-sub">{'LIVE' if is_today else 'HISTORICAL'} &nbsp;·&nbsp; {updated}</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        has_synth = "synth_ratio" in df.columns and df["synth_ratio"].notna().any()

        # Determine rows
        n_rows = 1 + int(show_diff) + int(has_synth)
        if n_rows == 3:
            row_heights = [0.55, 0.25, 0.20]
        elif n_rows == 2:
            row_heights = [0.70, 0.30]
        else:
            row_heights = [1.0]

        fig = make_subplots(
            rows=n_rows, cols=1,
            shared_xaxes=True,
            row_heights=row_heights,
            vertical_spacing=0.04
        )

        diff_row  = 2 if show_diff else None
        synth_row = (3 if show_diff else 2) if has_synth else None

        fig.add_trace(go.Scatter(x=df.index, y=df["ce_spread"], name="CE Spread", line=dict(color="#ff4444", width=2), hovertemplate="%{x|%H:%M}<br>CE: %{y:.2f}<extra></extra>"), row=1, col=1)
        fig.add_trace(go.Scatter(x=df.index, y=df["pe_spread"], name="PE Spread", line=dict(color="#44ff88", width=2), hovertemplate="%{x|%H:%M}<br>PE: %{y:.2f}<extra></extra>"), row=1, col=1)
        fig.add_hline(y=0, line_dash="dash", line_color="#444", row=1, col=1)

        if show_diff:
            fig.add_trace(go.Scatter(x=df.index, y=df["diff"], name="4 Leg", line=dict(color="#ffaa00", width=2), hovertemplate="%{x|%H:%M}<br>4 Leg: %{y:.2f}<extra></extra>"), row=diff_row, col=1)
            fig.add_hline(y=0, line_dash="dash", line_color="#444", row=diff_row, col=1)
            diff_high = df["diff"].max()
            diff_low  = df["diff"].min()
            fig.add_hline(y=diff_high, line_dash="dot", line_color="#ffaa00", line_width=1, opacity=0.5,
                annotation_text=f"H: {diff_high:.0f}", annotation_position="right",
                annotation_font=dict(color="#ffaa00", size=10), row=diff_row, col=1)
            fig.add_hline(y=diff_low, line_dash="dot", line_color="#ffaa00", line_width=1, opacity=0.5,
                annotation_text=f"L: {diff_low:.0f}", annotation_position="right",
                annotation_font=dict(color="#ffaa00", size=10), row=diff_row, col=1)

        if has_synth:
            fig.add_trace(go.Scatter(
                x=df.index, y=df["synth_ratio"], name="Synthetic Fut - Multiplier",
                line=dict(color="#818cf8", width=2),
                hovertemplate="%{x|%H:%M}<br>Synth: %{y:.4f}<extra></extra>"
            ), row=synth_row, col=1)
            ratio_high = df["synth_ratio"].max()
            ratio_low  = df["synth_ratio"].min()
            fig.add_hline(y=ratio_high, line_dash="dot", line_color="#818cf8", line_width=1, opacity=0.5,
                annotation_text=f"H: {ratio_high:.4f}", annotation_position="right",
                annotation_font=dict(color="#818cf8", size=10), row=synth_row, col=1)
            fig.add_hline(y=ratio_low, line_dash="dot", line_color="#818cf8", line_width=1, opacity=0.5,
                annotation_text=f"L: {ratio_low:.4f}", annotation_position="right",
                annotation_font=dict(color="#818cf8", size=10), row=synth_row, col=1)

        fig.update_layout(
            height=580 + (120 if has_synth else 0),
            plot_bgcolor=T["plot_bg"],
            paper_bgcolor=T["plot_bg"],
            font=dict(color=T["text2"], family="Space Mono"),
            legend=dict(
                bgcolor=T["card"], bordercolor=T["card_bdr"],
                borderwidth=1, font=dict(size=11),
                orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1
            ),
            hovermode="x unified",
            margin=dict(l=10, r=10, t=10, b=10),
            xaxis=dict(gridcolor=T["grid"], tickfont=dict(size=10)),
            yaxis=dict(gridcolor=T["grid"], title="Spread (₹)", tickfont=dict(size=10)),
            hoverlabel=dict(bgcolor=T["card"], bordercolor=T["card_bdr"], font=dict(color=T["text"])),
        )
        if show_diff:
            fig.update_yaxes(gridcolor=T["grid"], title_text="4 Leg", tickfont=dict(size=10), row=diff_row, col=1)
            fig.update_xaxes(gridcolor=T["grid"], tickfont=dict(size=10), row=diff_row, col=1)


        if has_synth:
            fig.update_yaxes(gridcolor=T["grid"], title_text="Synthetic Fut - Multiplier", tickfont=dict(size=10), row=synth_row, col=1)
            fig.update_xaxes(gridcolor=T["grid"], tickfont=dict(size=10), row=synth_row, col=1)

        st.plotly_chart(fig, use_container_width=True)
        if st.session_state.get("spot_debug"):
            st.warning(f"⚠️ Spot debug: {st.session_state['spot_debug']}")



    # ─────────────────────────────────────────────

# ─────────────────────────────────────────────
# TAB 3 — IV ANALYSIS
# ─────────────────────────────────────────────

with tab3:
    SENSEX_LOT = 20
    NIFTY_LOT  = 65

    def bs_price(S, K, T, r, sigma, opt):
        import math
        if T <= 0 or sigma <= 0:
            return max(0.0, S - K) if opt == "CE" else max(0.0, K - S)
        d1 = (math.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * math.sqrt(T))
        d2 = d1 - sigma * math.sqrt(T)
        from scipy.stats import norm
        if opt == "CE":
            return S * norm.cdf(d1) - K * math.exp(-r * T) * norm.cdf(d2)
        else:
            return K * math.exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)

    def calc_iv(mkt_price, S, K, T, r, opt):
        from scipy.optimize import brentq
        if T <= 0 or S <= 0 or K <= 0 or mkt_price <= 0:
            return float("nan")
        try:
            return brentq(lambda sig: bs_price(S, K, T, r, sig, opt) - mkt_price,
                          1e-6, 20.0, xtol=1e-6, maxiter=200) * 100
        except Exception:
            return float("nan")

    def expiry_to_date(s):
        import calendar as _cal
        s = s.strip().upper()
        MONTHS = {m:i+1 for i,m in enumerate(["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"])}
        # Monthly format: YYMON e.g. 26MAR
        if any(c.isalpha() for c in s):
            yy  = int(s[:2])
            mon = s[2:5]
            mm  = MONTHS.get(mon, 3)
            dd  = _cal.monthrange(2000+yy, mm)[1]
            return date(2000+yy, mm, dd)
        # Weekly 5-char: YYM DD e.g. 26416 (Apr 16) or 26325 (Mar 25)
        if len(s) == 5:
            yy = int(s[0:2])
            mm = int(s[2])
            dd = int(s[3:5])
            return date(2000+yy, mm, dd)
        # Weekly 6-char: YYMMDD e.g. 260325
        return date(2000 + int(s[0:2]), int(s[2:4]), int(s[4:6]))

    def round_to(val, base):
        return int(base * round(float(val) / base))

    # ── Controls ──
    st.markdown("<div style='font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#64748b;margin-bottom:4px;'>⚙ IV Settings</div>", unsafe_allow_html=True)
    iv_r0 = st.columns([1.2, 1, 1, 1, 1, 1, 1, 1.5])
    with iv_r0[0]: iv_date      = st.date_input("Date",          value=default_date,           key="iv_date")
    with iv_r0[1]: iv_interval  = st.selectbox("Interval (min)", [1,3,5,10,15,30,60], index=2, key="iv_interval")
    _iv_sx_opts = get_expiries_for("BSE", "SENSEX")
    _iv_nf_opts = get_expiries_for("NSE", "NIFTY")
    with iv_r0[2]: sx_iv_expiry = expiry_selectbox("Sensex Expiry", _iv_sx_opts, "iv_sx_man", "iv_sx_sel", "260312")
    with iv_r0[3]: nf_iv_expiry = expiry_selectbox("Nifty Expiry",  _iv_nf_opts, "iv_nf_man", "iv_nf_sel", "260310")
    with iv_r0[4]: iv_rate      = st.number_input("Risk-Free %", value=6.5, step=0.1,          key="iv_rate")
    with iv_r0[5]: iv_auto      = st.checkbox("Auto Refresh", value=True,                      key="iv_auto_ref")
    with iv_r0[6]: iv_ref_secs  = st.slider("Refresh (sec)", 5, 60, 15,                        key="iv_ref_sec")
    with iv_r0[7]: iv_fetch     = st.button("⟳  FETCH IV DATA", type="primary", use_container_width=True, key="iv_fetch")

    iv_date_str = iv_date.strftime("%Y-%m-%d")
    iv_mult = st.session_state.get("iv_synth_mult", None)

    if iv_mult:
        st.markdown(f"<div style='font-size:11px;color:#64748b;margin:2px 0 8px 0;'>Synthetic Fut - Multiplier: <b>{iv_mult:.4f}</b> &nbsp;|&nbsp; Sensex lot: <b>{SENSEX_LOT}</b> &nbsp;|&nbsp; Nifty lot: <b>{NIFTY_LOT}</b></div>", unsafe_allow_html=True)
    else:
        st.markdown(f"<div style='font-size:11px;color:#64748b;margin:2px 0 8px 0;'>Synthetic Fut - Multiplier: <i>fetched on load</i> &nbsp;|&nbsp; Sensex lot: <b>{SENSEX_LOT}</b> &nbsp;|&nbsp; Nifty lot: <b>{NIFTY_LOT}</b></div>", unsafe_allow_html=True)

    if iv_fetch or st.session_state.pop("_iv_rerun", False):
        fyers = get_fyers_client()
        if fyers is None:
            st.error("Not connected to Fyers.")
        else:
            with st.spinner("Fetching spot & option data for IV..."):
                df_sx_s = fetch_candles(fyers, "BSE:SENSEX-INDEX",  iv_interval, iv_date_str)
                if df_sx_s.empty:
                    df_sx_s = fetch_candles(fyers, "BSE:SENSEX", iv_interval, iv_date_str)
                df_nf_s = fetch_candles(fyers, "NSE:NIFTY50-INDEX", iv_interval, iv_date_str)
                if df_nf_s.empty:
                    df_nf_s = fetch_candles(fyers, "NSE:NIFTY50", iv_interval, iv_date_str)

            if df_sx_s.empty or df_nf_s.empty:
                st.error("⚠️ Could not fetch spot prices.")
            else:
                df_sx_s = df_sx_s[~df_sx_s.index.duplicated(keep="last")]
                df_nf_s = df_nf_s[~df_nf_s.index.duplicated(keep="last")]

                last_sx = df_sx_s["close"].iloc[-1]
                last_nf = df_nf_s["close"].iloc[-1]

                # Compute Synthetic Fut - Multiplier from spot prices
                # synth_ratio = synth_sensex / synth_nifty ≈ spot_sensex / spot_nifty (no options here)
                # Use per-minute ratio series, take last value
                common_ts = df_sx_s.index.intersection(df_nf_s.index)
                synth_mult_series = df_sx_s["close"].reindex(common_ts) / df_nf_s["close"].reindex(common_ts)
                iv_mult = round(float(synth_mult_series.dropna().iloc[-1]), 4)
                st.session_state["iv_synth_mult"] = iv_mult

                # ── Dynamic ATM: compute per-minute strikes ──
                # Graph 1 = ATM strike, Graph 2 = ATM + 500
                sx_prices = df_sx_s["close"].reindex(common_ts)

                # ATM = nearest 500 (rounded, not floor)
                # Graph 1 = ATM strike, Graph 2 = ATM + 500
                def atm_nearest(s):
                    return int(round(float(s) / 500) * 500)

                lo_sx_series = sx_prices.apply(atm_nearest)          # per-minute ATM
                hi_sx_series = lo_sx_series.apply(lambda k: k + 500) # per-minute ATM+500
                lo_nf_series = (lo_sx_series / synth_mult_series.reindex(lo_sx_series.index).ffill()).apply(lambda k: round_to(k, 50))
                hi_nf_series = (hi_sx_series / synth_mult_series.reindex(hi_sx_series.index).ffill()).apply(lambda k: round_to(k, 50))

                # All unique strikes needed
                uniq_sx_lo = sorted(lo_sx_series.unique())
                uniq_sx_hi = sorted(hi_sx_series.unique())
                uniq_nf_lo = sorted(lo_nf_series.unique())
                uniq_nf_hi = sorted(hi_nf_series.unique())

                # Fetch all unique option series
                all_syms = {}
                for k in uniq_sx_lo:
                    all_syms[f"sx_lo_CE_{k}"] = build_symbol("BSE","SENSEX", sx_iv_expiry,"C", int(k))
                    all_syms[f"sx_lo_PE_{k}"] = build_symbol("BSE","SENSEX", sx_iv_expiry,"P", int(k))
                for k in uniq_sx_hi:
                    all_syms[f"sx_hi_CE_{k}"] = build_symbol("BSE","SENSEX", sx_iv_expiry,"C", int(k))
                    all_syms[f"sx_hi_PE_{k}"] = build_symbol("BSE","SENSEX", sx_iv_expiry,"P", int(k))
                for k in uniq_nf_lo:
                    all_syms[f"nf_lo_CE_{k}"] = build_symbol("NSE","NIFTY",  nf_iv_expiry,"C", int(k))
                    all_syms[f"nf_lo_PE_{k}"] = build_symbol("NSE","NIFTY",  nf_iv_expiry,"P", int(k))
                for k in uniq_nf_hi:
                    all_syms[f"nf_hi_CE_{k}"] = build_symbol("NSE","NIFTY",  nf_iv_expiry,"C", int(k))
                    all_syms[f"nf_hi_PE_{k}"] = build_symbol("NSE","NIFTY",  nf_iv_expiry,"P", int(k))

                with st.spinner(f"Fetching {len(all_syms)} option series (dynamic ATM)..."):
                    fetched = {}
                    for key, sym in all_syms.items():
                        df_o = fetch_candles(fyers, sym, iv_interval, iv_date_str)
                        fetched[key] = df_o[~df_o.index.duplicated(keep="last")] if not df_o.empty else df_o

                # ── Compute IV per minute using that minute's ATM strike ──
                r = iv_rate / 100
                exp_sx = expiry_to_date(sx_iv_expiry)
                exp_nf = expiry_to_date(nf_iv_expiry)

                def dynamic_iv_series(spot_df, strike_series, fetched_dict, prefix, expiry_dt, opt_type):
                    """Build IV series where strike can change each minute."""
                    out_iv     = {}
                    out_strike = {}
                    valid_ts   = spot_df.index.intersection(strike_series.index)
                    for ts in valid_ts:
                        S       = spot_df.loc[ts, "close"]
                        K       = int(strike_series.loc[ts])
                        opt_key = f"{prefix}_{K}"
                        df_o    = fetched_dict.get(opt_key)
                        if df_o is None or df_o.empty or ts not in df_o.index: continue
                        price   = df_o.loc[ts, "close"]
                        T       = max((expiry_dt - ts.date()).days / 365, 1/365)
                        out_iv[ts]     = calc_iv(price, S, K, T, r, opt_type)
                        out_strike[ts] = K
                    return pd.Series(out_iv, dtype=float), pd.Series(out_strike, dtype=float)

                iv_sx_lo_CE, sk_sx_lo_CE = dynamic_iv_series(df_sx_s, lo_sx_series, fetched, "sx_lo_CE", exp_sx, "CE")
                iv_sx_lo_PE, sk_sx_lo_PE = dynamic_iv_series(df_sx_s, lo_sx_series, fetched, "sx_lo_PE", exp_sx, "PE")
                iv_nf_lo_CE, sk_nf_lo_CE = dynamic_iv_series(df_nf_s, lo_nf_series, fetched, "nf_lo_CE", exp_nf, "CE")
                iv_nf_lo_PE, sk_nf_lo_PE = dynamic_iv_series(df_nf_s, lo_nf_series, fetched, "nf_lo_PE", exp_nf, "PE")
                iv_sx_hi_CE, sk_sx_hi_CE = dynamic_iv_series(df_sx_s, hi_sx_series, fetched, "sx_hi_CE", exp_sx, "CE")
                iv_sx_hi_PE, sk_sx_hi_PE = dynamic_iv_series(df_sx_s, hi_sx_series, fetched, "sx_hi_PE", exp_sx, "PE")
                iv_nf_hi_CE, sk_nf_hi_CE = dynamic_iv_series(df_nf_s, hi_nf_series, fetched, "nf_hi_CE", exp_nf, "CE")
                iv_nf_hi_PE, sk_nf_hi_PE = dynamic_iv_series(df_nf_s, hi_nf_series, fetched, "nf_hi_PE", exp_nf, "PE")

                # Strike-change timestamps — debounced (strike must hold for 3+ candles)
                def strike_changes(sk_series, min_candles=3):
                    """Only mark a strike change if new strike persists min_candles."""
                    if sk_series.empty:
                        return []
                    items = list(sk_series.items())
                    changes = []
                    prev_k = items[0][1]
                    run_k, run_start, run_len = items[0][1], items[0][0], 1
                    confirmed_k = prev_k
                    for ts, k in items[1:]:
                        if k == run_k:
                            run_len += 1
                            if run_len == min_candles and run_k != confirmed_k:
                                changes.append((run_start, int(run_k)))
                                confirmed_k = run_k
                        else:
                            run_k, run_start, run_len = k, ts, 1
                    return changes

                iv_res = {
                    "sx_lo_CE": iv_sx_lo_CE, "sx_lo_PE": iv_sx_lo_PE,
                    "nf_lo_CE": iv_nf_lo_CE, "nf_lo_PE": iv_nf_lo_PE,
                    "sx_hi_CE": iv_sx_hi_CE, "sx_hi_PE": iv_sx_hi_PE,
                    "nf_hi_CE": iv_nf_hi_CE, "nf_hi_PE": iv_nf_hi_PE,
                }
                iv_changes = {
                    "lo_sx": strike_changes(sk_sx_lo_CE),
                    "lo_nf": strike_changes(sk_nf_lo_CE),
                    "hi_sx": strike_changes(sk_sx_hi_CE),
                    "hi_nf": strike_changes(sk_nf_hi_CE),
                }

                iv_sk = {
                    "sx_lo_CE": sk_sx_lo_CE, "sx_lo_PE": sk_sx_lo_PE,
                    "nf_lo_CE": sk_nf_lo_CE, "nf_lo_PE": sk_nf_lo_PE,
                    "sx_hi_CE": sk_sx_hi_CE, "sx_hi_PE": sk_sx_hi_PE,
                    "nf_hi_CE": sk_nf_hi_CE, "nf_hi_PE": sk_nf_hi_PE,
                }
                st.session_state["iv_res"]       = iv_res
                st.session_state["iv_sk"]        = iv_sk
                st.session_state["iv_changes"]   = iv_changes
                st.session_state["iv_lo_sx"]     = int(lo_sx_series.iloc[-1])
                st.session_state["iv_hi_sx"]     = int(hi_sx_series.iloc[-1])
                st.session_state["iv_lo_nf"]     = int(lo_nf_series.iloc[-1])
                st.session_state["iv_hi_nf"]     = int(hi_nf_series.iloc[-1])
                st.session_state["iv_last_sx"]   = last_sx
                # Strike ranges used across the day
                st.session_state["iv_lo_sx_range"] = sorted(lo_sx_series.unique())
                st.session_state["iv_hi_sx_range"] = sorted(hi_sx_series.unique())
                st.session_state["iv_lo_nf_range"] = sorted(lo_nf_series.unique())
                st.session_state["iv_hi_nf_range"] = sorted(hi_nf_series.unique())

    # ── Render ──
    if "iv_res" in st.session_state:
        iv_res       = st.session_state["iv_res"]
        iv_sk        = st.session_state.get("iv_sk", {})
        iv_changes   = st.session_state.get("iv_changes", {})
        lo_sx        = st.session_state["iv_lo_sx"]; hi_sx  = st.session_state["iv_hi_sx"]
        lo_nf        = st.session_state["iv_lo_nf"]; hi_nf  = st.session_state["iv_hi_nf"]
        last_sx      = st.session_state.get("iv_last_sx", 0)
        lo_sx_range  = st.session_state.get("iv_lo_sx_range", [lo_sx])
        hi_sx_range  = st.session_state.get("iv_hi_sx_range", [hi_sx])
        lo_nf_range  = st.session_state.get("iv_lo_nf_range", [lo_nf])
        hi_nf_range  = st.session_state.get("iv_hi_nf_range", [hi_nf])

        def range_label(strikes):
            if len(strikes) == 1: return str(strikes[0])
            return f"{min(strikes)}–{max(strikes)}"

        st.markdown(f"""<div style='font-size:12px;color:#64748b;background:#f1f5f9;
            border-radius:6px;padding:8px 12px;margin:4px 0 10px 0;font-family:monospace;'>
            Sensex spot: <b>{last_sx:.0f}</b> &nbsp;→&nbsp;
            Graph 1: Sensex <b>{lo_sx}</b> / Nifty <b>{lo_nf}</b>
            &nbsp;|&nbsp;
            Graph 2: Sensex <b>{hi_sx}</b> / Nifty <b>{hi_nf}</b>
        </div>""", unsafe_allow_html=True)

        COLORS = {"sx_CE":"#f87171","sx_PE":"#fca5a5","nf_CE":"#60a5fa","nf_PE":"#93c5fd"}

        def card(label, series, color, lot):
            if series is not None and not series.dropna().empty:
                val = series.dropna().iloc[-1]
                return f"""<div style='background:#fff;border:1px solid #e2e8f0;border-top:3px solid {color};
                    border-radius:8px;padding:10px 12px;'>
                    <div style='font-size:9px;font-weight:700;letter-spacing:1px;color:#94a3b8;text-transform:uppercase;'>{label}</div>
                    <div style='font-size:22px;font-weight:800;color:{color};margin:4px 0 2px 0;'>{val:.1f}%</div>
                    <div style='font-size:11px;color:#64748b;'>Lot: {lot}</div></div>"""
            return f"""<div style='background:#fff;border:1px solid #e2e8f0;border-top:3px solid {color};
                border-radius:8px;padding:10px 12px;'>
                <div style='font-size:9px;color:#94a3b8;text-transform:uppercase;'>{label}</div>
                <div style='font-size:16px;color:#cbd5e1;'>No data</div></div>"""

        def iv_chart(pfx, sx_k, nf_k, title, chg_sx=None, chg_nf=None):
            fig = go.Figure()
            nfx = pfx.replace("sx","nf")
            entries = [
                (f"{pfx}_CE", "Sensex CE", COLORS["sx_CE"], 2),
                (f"{pfx}_PE", "Sensex PE", COLORS["sx_PE"], 1.5),
                (f"{nfx}_CE", "Nifty CE",  COLORS["nf_CE"], 2),
                (f"{nfx}_PE", "Nifty PE",  COLORS["nf_PE"], 1.5),
            ]
            for key, name, color, width in entries:
                s  = iv_res.get(key, pd.Series(dtype=float)).dropna()
                sk = iv_sk.get(key, pd.Series(dtype=float))
                if not s.empty:
                    sk_aligned = sk.reindex(s.index).ffill().fillna(0).astype(int)
                    hover_text = [f"Strike: {k}<br>IV: {iv:.2f}%"
                                  for iv, k in zip(s.values, sk_aligned.values)]
                    latest_iv  = s.iloc[-1]
                    latest_sk  = int(sk_aligned.iloc[-1]) if not sk_aligned.empty else sx_k
                    fig.add_trace(go.Scatter(
                        x=s.index, y=s.values,
                        name=f"{name} (K:{latest_sk} · {latest_iv:.1f}%)",
                        line=dict(color=color, width=width),
                        text=hover_text,
                        hovertemplate="%{text}<extra>" + name + "</extra>",
                    ))

            # Strike-change vertical lines — Sensex (orange) and Nifty (purple)
            for ts, new_k in (chg_sx or []):
                fig.add_shape(type="line", x0=str(ts), x1=str(ts), y0=0, y1=1,
                    xref="x", yref="paper",
                    line=dict(color="#f97316", width=1.5, dash="dash"))
                fig.add_annotation(x=str(ts), y=1, xref="x", yref="paper",
                    text=f"SX→{new_k}", showarrow=False, yanchor="bottom",
                    font=dict(color="#f97316", size=9), bgcolor="rgba(255,255,255,0.7)")
            for ts, new_k in (chg_nf or []):
                fig.add_shape(type="line", x0=str(ts), x1=str(ts), y0=0, y1=1,
                    xref="x", yref="paper",
                    line=dict(color="#a855f7", width=1.5, dash="dot"))
                fig.add_annotation(x=str(ts), y=0, xref="x", yref="paper",
                    text=f"NF→{new_k}", showarrow=False, yanchor="top",
                    font=dict(color="#a855f7", size=9), bgcolor="rgba(255,255,255,0.7)")

            fig.update_layout(
                title=dict(text=title, font=dict(size=12, color="#64748b"), x=0),
                height=400, plot_bgcolor="#f8fafc", paper_bgcolor="#f8fafc",
                font=dict(color="#334155"), hovermode="x unified",
                margin=dict(l=10, r=10, t=40, b=10),
                legend=dict(bgcolor="#fff", bordercolor="#e2e8f0", borderwidth=1,
                    orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                xaxis=dict(gridcolor="#e2e8f0", tickfont=dict(size=10),
                    showspikes=True, spikemode="across", spikecolor="#94a3b8", spikethickness=1),
                yaxis=dict(gridcolor="#e2e8f0", title="IV %", tickfont=dict(size=10),
                    showspikes=True, spikemode="across", spikecolor="#94a3b8", spikethickness=1),
                hoverlabel=dict(bgcolor="#fff", bordercolor="#e2e8f0"),
            )
            return fig

        # Graph 1
        st.markdown(f"<div style='font-size:12px;font-weight:700;color:#64748b;margin:10px 0 6px 0;'>📉 Graph 1 — Sensex ATM &nbsp;<span style='color:#f87171'>{range_label(lo_sx_range)}</span> &nbsp;/ Nifty <span style='color:#60a5fa'>{range_label(lo_nf_range)}</span> &nbsp;<span style='font-weight:400;font-size:11px;'>(dynamic ATM · closing: {lo_sx}/{lo_nf})</span></div>", unsafe_allow_html=True)
        c1,c2,c3,c4 = st.columns(4)
        c1.markdown(card(f"Sensex ATM CE IV ({range_label(lo_sx_range)})", iv_res.get("sx_lo_CE"), COLORS["sx_CE"], SENSEX_LOT), unsafe_allow_html=True)
        c2.markdown(card(f"Sensex ATM PE IV ({range_label(lo_sx_range)})", iv_res.get("sx_lo_PE"), COLORS["sx_PE"], SENSEX_LOT), unsafe_allow_html=True)
        c3.markdown(card(f"Nifty ATM CE IV ({range_label(lo_nf_range)})",  iv_res.get("nf_lo_CE"), COLORS["nf_CE"], NIFTY_LOT),  unsafe_allow_html=True)
        c4.markdown(card(f"Nifty ATM PE IV ({range_label(lo_nf_range)})",  iv_res.get("nf_lo_PE"), COLORS["nf_PE"], NIFTY_LOT),  unsafe_allow_html=True)
        st.plotly_chart(iv_chart("sx_lo", lo_sx, lo_nf, f"IV % — Sensex ATM {range_label(lo_sx_range)} & Nifty ATM {range_label(lo_nf_range)}", iv_changes.get("lo_sx"), iv_changes.get("lo_nf")), use_container_width=True)

        # ── IV Differential Charts ──
        def diff_chart(ce_sx_key, ce_nf_key, pe_sx_key, pe_nf_key, title):
            fig = go.Figure()
            ce_sx = iv_res.get(ce_sx_key, pd.Series(dtype=float)).dropna()
            ce_nf = iv_res.get(ce_nf_key, pd.Series(dtype=float)).dropna()
            pe_sx = iv_res.get(pe_sx_key, pd.Series(dtype=float)).dropna()
            pe_nf = iv_res.get(pe_nf_key, pd.Series(dtype=float)).dropna()
            # CE diff
            common_ce = ce_sx.index.intersection(ce_nf.index)
            if len(common_ce) > 0:
                ce_diff = ce_sx.reindex(common_ce) - ce_nf.reindex(common_ce)
                fig.add_trace(go.Scatter(x=ce_diff.index, y=ce_diff.values,
                    name=f"CE Diff (last: {ce_diff.iloc[-1]:.1f}%)",
                    line=dict(color="red", width=2),
                    hovertemplate="CE Diff: %{y:.2f}%<extra></extra>"))
            # PE diff
            common_pe = pe_sx.index.intersection(pe_nf.index)
            if len(common_pe) > 0:
                pe_diff = pe_sx.reindex(common_pe) - pe_nf.reindex(common_pe)
                fig.add_trace(go.Scatter(x=pe_diff.index, y=pe_diff.values,
                    name=f"PE Diff (last: {pe_diff.iloc[-1]:.1f}%)",
                    line=dict(color="green", width=2),
                    hovertemplate="PE Diff: %{y:.2f}%<extra></extra>"))
            fig.add_hline(y=0, line_dash="dash", line_color="#94a3b8", line_width=1)
            fig.update_layout(
                title=dict(text=title, font=dict(size=12, color="#64748b"), x=0),
                height=320, plot_bgcolor="#f8fafc", paper_bgcolor="#f8fafc",
                font=dict(color="#334155"), hovermode="x unified",
                margin=dict(l=10, r=10, t=40, b=10),
                legend=dict(bgcolor="#fff", bordercolor="#e2e8f0", borderwidth=1,
                    orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                xaxis=dict(gridcolor="#e2e8f0", tickfont=dict(size=10),
                    showspikes=True, spikemode="across", spikecolor="#94a3b8", spikethickness=1),
                yaxis=dict(gridcolor="#e2e8f0", title="IV Diff %", tickfont=dict(size=10),
                    showspikes=True, spikemode="across", spikecolor="#94a3b8", spikethickness=1),
                hoverlabel=dict(bgcolor="#fff", bordercolor="#e2e8f0"),
            )
            return fig

        st.markdown("<div style='font-size:12px;font-weight:700;color:#64748b;margin:16px 0 6px 0;'>📊 IV Differential — Sensex IV − Nifty IV (ATM)</div>", unsafe_allow_html=True)
        st.plotly_chart(diff_chart("sx_lo_CE","nf_lo_CE","sx_lo_PE","nf_lo_PE", "Sensex CE IV − Nifty CE IV  &  Sensex PE IV − Nifty PE IV"), use_container_width=True)

        # ── Auto Refresh — DEFERRED (was halting Tab 5 from rendering) ──
        if iv_auto and iv_date_str == date.today().strftime("%Y-%m-%d"):
            st.session_state["_iv_rerun"] = True
            st.session_state["_iv_rerun_pending"] = True

    else:
        st.info("👆 Set expiry dates above and click **Fetch IV Data**.")

# AUTO REFRESH — DEFERRED
# ─────────────────────────────────────────────
# Previously this block called st.rerun() inline. That halted script execution
# BEFORE `with tab5:` (below) could render, leaving Tab 5 permanently blank
# once Tab 1 had fetched data with Auto Refresh on. Now we just flag it and
# perform the rerun at the very END of the script.

if auto_refresh and date_str == date.today().strftime("%Y-%m-%d") and not df.empty:
    st.session_state["_main_rerun_pending"] = True


# ─────────────────────────────────────────────
# TAB 5 — MCX SPREAD

# ─────────────────────────────────────────────
# TAB 5 — MCX SPREAD DASHBOARD
# ─────────────────────────────────────────────

MCX_UNDERLYINGS_BIG  = ["SILVER", "GOLD", "CRUDEOIL", "NATURALGAS"]
MCX_UNDERLYINGS_MINI = ["SILVERM", "GOLDM", "CRUDEOILM", "NATURALGASM"]
MCX_UNDERLYINGS_ALL  = MCX_UNDERLYINGS_BIG + MCX_UNDERLYINGS_MINI

# Big-contract → mini-contract pairing for the auto-pair toggle.
MCX_BIG_TO_MINI = {
    "SILVER":     "SILVERM",
    "GOLD":       "GOLDM",
    "CRUDEOIL":   "CRUDEOILM",
    "NATURALGAS": "NATURALGASM",
}

# Typical strike & step per MCX commodity — used to seed the strike inputs sensibly.
# Big & mini share the same underlying price, so strike defaults are identical.
MCX_STRIKE_DEFAULTS = {
    "SILVER":      (90000, 250),
    "SILVERM":     (90000, 250),
    "GOLD":        (75000, 100),
    "GOLDM":       (75000, 100),
    "CRUDEOIL":    (5500,  50),
    "CRUDEOILM":   (5500,  50),
    "NATURALGAS":  (300,   5),
    "NATURALGASM": (300,   5),
}

with tab5:
    # ── PROOF-OF-LIFE BANNER ─────────────────────────────────────────────
    # If you see this banner, the Tab 5 code block IS running.
    # If you do NOT see this banner, the whole tab is failing to render
    # (Streamlit error, indentation issue, or you're looking at the wrong tab).
    import datetime as _dt
    st.markdown(
        f"<div style='background:#fef3c7;border:2px solid #f59e0b;"
        f"padding:8px 12px;border-radius:6px;margin:0 0 10px 0;"
        f"font-family:monospace;font-size:12px;color:#92400e;'>"
        f"✅ <b>TAB 5 IS RENDERING</b> &nbsp;·&nbsp; "
        f"rerun at {_dt.datetime.now().strftime('%H:%M:%S')} "
        f"·&nbsp; if you see this, the code block is alive."
        f"</div>",
        unsafe_allow_html=True,
    )

    # ── Diagnostic log: must come FIRST so it survives any later exception ──
    _mcx_logs = []
    def _mcxlog(msg):
        line = str(msg)
        _mcx_logs.append(line)
        try:
            print(f"[MCX] {line}", flush=True)
        except Exception:
            pass

    _mcxlog(f"── tab5 render start · today={date.today().isoformat()} ──")

    # Collapsible diagnostic log — closed by default. Click to expand.
    # Lives inside an st.empty() so we can rewrite the whole expander on every
    # _refresh_log_top() call as more entries accumulate.
    _mcx_log_slot = st.empty()
    with _mcx_log_slot.container():
        with st.expander("🪵 MCX Diagnostic Log", expanded=False):
            st.code("(MCX log — will update as the tab renders)", language="text")

    st.markdown(
        "<div style='font-size:10px;font-weight:700;letter-spacing:1.5px;"
        "text-transform:uppercase;color:#64748b;margin-bottom:4px;'>⚙ MCX Settings</div>",
        unsafe_allow_html=True,
    )

    def _refresh_log_top():
        with _mcx_log_slot.container():
            with st.expander("🪵 MCX Diagnostic Log", expanded=False):
                st.code(
                    "\n".join(_mcx_logs) if _mcx_logs else "(no log entries)",
                    language="text",
                )

    # ── Top control row ──
    mcx_r0 = st.columns([1.1, 0.9, 0.9, 0.9, 1.0, 1.4])
    with mcx_r0[0]: mcx_date     = st.date_input("Date",          value=default_date,            key="mcx_date")
    with mcx_r0[1]: mcx_interval = st.selectbox("Interval (min)", [1, 3, 5, 10, 15, 30, 60], index=2, key="mcx_interval")
    with mcx_r0[2]: mcx_auto     = st.checkbox("Auto Refresh",    value=True,                    key="mcx_auto_ref")
    with mcx_r0[3]: mcx_ref_secs = st.slider("Refresh (sec)",     5, 60, REFRESH_SECONDS,        key="mcx_ref_sec")
    with mcx_r0[4]: mcx_pair_mini = st.checkbox(
        "🔗 Pair Mini", value=True, key="mcx_pair_mini",
        help="When ON, LEG 2 is auto-set to the MINI of LEG 1 (e.g., SILVER → SILVERM). "
             "When OFF, LEG 2 can be any of the 8 contracts."
    )
    with mcx_r0[5]: mcx_fetch_btn = st.button("⟳  FETCH MCX DATA", use_container_width=True, type="primary", key="mcx_fetch_btn")

    mcx_date_str = mcx_date.strftime("%Y-%m-%d")

    # ── Leg configuration row — exchange fixed to MCX for both legs ──
    mcx_legs = st.columns([0.2, 0.75, 0.75, 0.75, 0.65, 0.65,
                            0.12,
                            0.2, 0.75, 0.75, 0.75, 0.65, 0.65])

    # --- LEG 1 ---
    mcx_legs[0].markdown(
        "<div style='padding-top:26px;font-size:10px;font-weight:700;"
        "letter-spacing:1px;color:#dc2626;'>LEG 1<br>"
        "<span style='color:#f59e0b;font-size:9px;'>MCX</span></div>",
        unsafe_allow_html=True,
    )
    with mcx_legs[1]:
        # LEG 1 is always one of the BIG contracts. (The mini sits in LEG 2.)
        mcx_l1_under = st.selectbox("Underlying", MCX_UNDERLYINGS_BIG, index=0, key="mcx_l1_under")

    # Expiries via the existing get_expiries_for — it already handles MCX:CRUDEOIL-INDEX
    _mcx_l1_opts = get_expiries_for("MCX", mcx_l1_under)
    _l1_sym = _UNDERLYING_SYM.get(mcx_l1_under.upper(), f"MCX:{mcx_l1_under}-INDEX")
    _mcxlog(f"LEG1 underlying={mcx_l1_under} (chain-symbol={_l1_sym}) → "
            f"{len(_mcx_l1_opts)} expiries: {list(_mcx_l1_opts.keys())[:6]}")
    _refresh_log_top()

    with mcx_legs[2]:
        mcx_l1_ce_exp = expiry_selectbox(
            "CE Expiry", _mcx_l1_opts, "mcx_l1_ce_man", "mcx_l1_ce_sel", ""
        )
    with mcx_legs[3]:
        mcx_l1_pe_exp = expiry_selectbox(
            "PE Expiry", _mcx_l1_opts, "mcx_l1_pe_man", "mcx_l1_pe_sel", ""
        )
    _l1_def, _l1_step = MCX_STRIKE_DEFAULTS.get(mcx_l1_under, (5000, 50))
    with mcx_legs[4]:
        mcx_l1_ce_str = st.number_input(
            "CE Strike", value=_l1_def, step=_l1_step, key=f"mcx_l1_ce_str_{mcx_l1_under}"
        )
    with mcx_legs[5]:
        mcx_l1_pe_str = st.number_input(
            "PE Strike", value=_l1_def, step=_l1_step, key=f"mcx_l1_pe_str_{mcx_l1_under}"
        )

    # divider
    mcx_legs[6].markdown(
        "<div style='padding-top:26px;font-size:10px;color:#e2e8f0;text-align:center;'>│</div>",
        unsafe_allow_html=True,
    )

    # --- LEG 2 ---
    mcx_legs[7].markdown(
        "<div style='padding-top:26px;font-size:10px;font-weight:700;"
        "letter-spacing:1px;color:#0284c7;'>LEG 2<br>"
        "<span style='color:#f59e0b;font-size:9px;'>MCX</span></div>",
        unsafe_allow_html=True,
    )
    with mcx_legs[8]:
        if mcx_pair_mini:
            # Auto-paired: LEG 2 is forced to the MINI of LEG 1.
            mcx_l2_under = MCX_BIG_TO_MINI.get(mcx_l1_under, MCX_UNDERLYINGS_MINI[0])
            st.markdown(
                "<div style='font-size:11px;color:#64748b;'>Underlying</div>"
                f"<div style='padding:6px 0 0 0;font-size:14px;font-weight:600;color:#0284c7;'>"
                f"🔗 {mcx_l2_under} <span style='font-size:9px;color:#94a3b8;'>(auto)</span></div>",
                unsafe_allow_html=True,
            )
        else:
            # Free pick from any of the 8 (big + mini).
            mcx_l2_under = st.selectbox(
                "Underlying", MCX_UNDERLYINGS_ALL,
                index=MCX_UNDERLYINGS_ALL.index(MCX_BIG_TO_MINI.get(mcx_l1_under, MCX_UNDERLYINGS_MINI[0])),
                key="mcx_l2_under_free",
            )

    _mcx_l2_opts = get_expiries_for("MCX", mcx_l2_under)
    _l2_sym = _UNDERLYING_SYM.get(mcx_l2_under.upper(), f"MCX:{mcx_l2_under}-INDEX")
    _mcxlog(f"LEG2 underlying={mcx_l2_under} (chain-symbol={_l2_sym}) → "
            f"{len(_mcx_l2_opts)} expiries: {list(_mcx_l2_opts.keys())[:6]}")
    _refresh_log_top()

    with mcx_legs[9]:
        mcx_l2_ce_exp = expiry_selectbox(
            "CE Expiry", _mcx_l2_opts, "mcx_l2_ce_man", "mcx_l2_ce_sel", ""
        )
    with mcx_legs[10]:
        mcx_l2_pe_exp = expiry_selectbox(
            "PE Expiry", _mcx_l2_opts, "mcx_l2_pe_man", "mcx_l2_pe_sel", ""
        )
    _l2_def, _l2_step = MCX_STRIKE_DEFAULTS.get(mcx_l2_under, (5000, 50))
    with mcx_legs[11]:
        mcx_l2_ce_str = st.number_input(
            "CE Strike", value=_l2_def, step=_l2_step, key=f"mcx_l2_ce_str_{mcx_l2_under}"
        )
    with mcx_legs[12]:
        mcx_l2_pe_str = st.number_input(
            "PE Strike", value=_l2_def, step=_l2_step, key=f"mcx_l2_pe_str_{mcx_l2_under}"
        )

    # ── LEG 2 multiplier row ──
    # spread_CE = L1_CE − (CE_ratio × L2_CE);   spread_PE = L1_PE − (PE_ratio × L2_PE)
    # Recomputed on every render — change the ratio and the chart updates without re-fetching.
    mcx_ratio_row = st.columns([0.2, 4.5, 1, 1, 0.5])
    mcx_ratio_row[0].markdown(
        "<div style='padding-top:30px;font-size:10px;font-weight:700;"
        "letter-spacing:1px;color:#0284c7;'>⚖<br>L2</div>",
        unsafe_allow_html=True,
    )
    mcx_ratio_row[1].markdown(
        f"<div style='padding-top:30px;font-size:11px;color:#64748b;'>"
        f"Spread CE = <b style='color:#dc2626;'>{mcx_l1_under} CE</b> − "
        f"<b style='color:#0284c7;'>CE&nbsp;Ratio × {mcx_l2_under} CE</b><br>"
        f"Spread PE = <b style='color:#dc2626;'>{mcx_l1_under} PE</b> − "
        f"<b style='color:#0284c7;'>PE&nbsp;Ratio × {mcx_l2_under} PE</b>"
        f"</div>",
        unsafe_allow_html=True,
    )
    with mcx_ratio_row[2]:
        mcx_l2_ce_ratio = st.number_input(
            "CE Ratio", value=1.00, step=0.05, min_value=0.0,
            format="%.2f", key="mcx_l2_ce_ratio",
            help="Multiplier applied to LEG 2 CE before subtracting from LEG 1 CE.",
        )
    with mcx_ratio_row[3]:
        mcx_l2_pe_ratio = st.number_input(
            "PE Ratio", value=1.00, step=0.05, min_value=0.0,
            format="%.2f", key="mcx_l2_pe_ratio",
            help="Multiplier applied to LEG 2 PE before subtracting from LEG 1 PE.",
        )
    _mcxlog(f"Ratios → CE={mcx_l2_ce_ratio} PE={mcx_l2_pe_ratio}")

    st.divider()

    # ── Show which symbols will be built (debug info — hidden unless expiry available) ──
    _l1_ce_exp_ok = bool(mcx_l1_ce_exp and mcx_l1_ce_exp.strip())
    _l1_pe_exp_ok = bool(mcx_l1_pe_exp and mcx_l1_pe_exp.strip())
    _l2_ce_exp_ok = bool(mcx_l2_ce_exp and mcx_l2_ce_exp.strip())
    _l2_pe_exp_ok = bool(mcx_l2_pe_exp and mcx_l2_pe_exp.strip())
    _all_exp_ok   = _l1_ce_exp_ok and _l1_pe_exp_ok and _l2_ce_exp_ok and _l2_pe_exp_ok
    _mcxlog(f"Expiry selections → L1 CE={mcx_l1_ce_exp!r} PE={mcx_l1_pe_exp!r} | "
            f"L2 CE={mcx_l2_ce_exp!r} PE={mcx_l2_pe_exp!r}")
    _mcxlog(f"All expiries OK? {_all_exp_ok} "
            f"(L1CE={_l1_ce_exp_ok} L1PE={_l1_pe_exp_ok} L2CE={_l2_ce_exp_ok} L2PE={_l2_pe_exp_ok})")

    if _all_exp_ok:
        _sym_l1_ce = build_symbol("MCX", mcx_l1_under, mcx_l1_ce_exp, "C", int(mcx_l1_ce_str))
        _sym_l1_pe = build_symbol("MCX", mcx_l1_under, mcx_l1_pe_exp, "P", int(mcx_l1_pe_str))
        _sym_l2_ce = build_symbol("MCX", mcx_l2_under, mcx_l2_ce_exp, "C", int(mcx_l2_ce_str))
        _sym_l2_pe = build_symbol("MCX", mcx_l2_under, mcx_l2_pe_exp, "P", int(mcx_l2_pe_str))
        st.markdown(
            f"<div style='font-size:10px;color:#64748b;font-family:monospace;margin-bottom:6px;'>"
            f"Symbols: "
            f"<span style='color:#dc2626;'>{_sym_l1_ce}</span> · "
            f"<span style='color:#dc2626;'>{_sym_l1_pe}</span> &nbsp;|&nbsp; "
            f"<span style='color:#0284c7;'>{_sym_l2_ce}</span> · "
            f"<span style='color:#0284c7;'>{_sym_l2_pe}</span>"
            f"</div>",
            unsafe_allow_html=True,
        )
    else:
        st.info("⏳ Waiting for expiry data from Fyers… Select underlying and expiry will populate automatically.")

    # ── Fetch on button click ONLY (no auto-fetch on empty) ──
    def _fetch_mcx_data():
        _mcxlog("── FETCH started ──")
        if not _all_exp_ok:
            _mcxlog("ABORT: expiries not all set.")
            st.warning("⚠️ Expiry not set. Please wait for expiry dropdown to populate.")
            return pd.DataFrame()
        fyers = get_fyers_client()
        if fyers is None:
            _mcxlog("ABORT: get_fyers_client() returned None (login/token failure).")
            return pd.DataFrame()
        _mcxlog("Fyers client OK.")
        sym_l1_ce = build_symbol("MCX", mcx_l1_under, mcx_l1_ce_exp, "C", int(mcx_l1_ce_str))
        sym_l1_pe = build_symbol("MCX", mcx_l1_under, mcx_l1_pe_exp, "P", int(mcx_l1_pe_str))
        sym_l2_ce = build_symbol("MCX", mcx_l2_under, mcx_l2_ce_exp, "C", int(mcx_l2_ce_str))
        sym_l2_pe = build_symbol("MCX", mcx_l2_under, mcx_l2_pe_exp, "P", int(mcx_l2_pe_str))
        _mcxlog(f"Symbols built: {sym_l1_ce} | {sym_l1_pe} | {sym_l2_ce} | {sym_l2_pe}")
        _mcxlog(f"Fetching candles: interval={mcx_interval} date={mcx_date_str}")
        with st.spinner("Fetching MCX option data from Fyers…"):
            df_l1_ce = fetch_candles(fyers, sym_l1_ce, mcx_interval, mcx_date_str)
            df_l1_pe = fetch_candles(fyers, sym_l1_pe, mcx_interval, mcx_date_str)
            df_l2_ce = fetch_candles(fyers, sym_l2_ce, mcx_interval, mcx_date_str)
            df_l2_pe = fetch_candles(fyers, sym_l2_pe, mcx_interval, mcx_date_str)
        _mcxlog(f"Rows returned → L1CE={len(df_l1_ce)} L1PE={len(df_l1_pe)} "
                f"L2CE={len(df_l2_ce)} L2PE={len(df_l2_pe)}")
        missing = [n for n, d in [
            (sym_l1_ce, df_l1_ce), (sym_l1_pe, df_l1_pe),
            (sym_l2_ce, df_l2_ce), (sym_l2_pe, df_l2_pe),
        ] if d.empty]
        if missing:
            _mcxlog(f"ABORT: empty data for {missing}")
            st.warning(f"⚠️ No data returned for: `{'` | `'.join(missing)}`")
            return pd.DataFrame()
        for _d in [df_l1_ce, df_l1_pe, df_l2_ce, df_l2_pe]:
            _d.drop_duplicates(keep="last", inplace=True)
        df_l1_ce = df_l1_ce[~df_l1_ce.index.duplicated(keep="last")]
        df_l1_pe = df_l1_pe[~df_l1_pe.index.duplicated(keep="last")]
        df_l2_ce = df_l2_ce[~df_l2_ce.index.duplicated(keep="last")]
        df_l2_pe = df_l2_pe[~df_l2_pe.index.duplicated(keep="last")]
        common = (df_l1_ce.index
                  .intersection(df_l1_pe.index)
                  .intersection(df_l2_ce.index)
                  .intersection(df_l2_pe.index))
        _mcxlog(f"Common timestamps across all 4 series: {len(common)}")
        if common.empty:
            _mcxlog("ABORT: no overlapping timestamps.")
            st.warning("⚠️ No overlapping timestamps across all 4 series.")
            return pd.DataFrame()
        out = pd.DataFrame({
            "l1_ce": df_l1_ce["close"].reindex(common),
            "l1_pe": df_l1_pe["close"].reindex(common),
            "l2_ce": df_l2_ce["close"].reindex(common),
            "l2_pe": df_l2_pe["close"].reindex(common),
        }).dropna()
        # Spreads are applied at render-time (so ratio edits redraw instantly).
        _mcxlog(f"SUCCESS: built raw frame with {len(out)} rows (ratios applied at render).")
        return out

    _mcxlog(f"Fetch button pressed? {bool(mcx_fetch_btn)}")
    if mcx_fetch_btn:
        st.session_state.df_mcx = _fetch_mcx_data()

    df_mcx = st.session_state.df_mcx
    _mcxlog(f"df_mcx in session_state: {len(df_mcx)} rows (empty={df_mcx.empty})")

    # ── Apply ratios at render-time so the chart redraws when CE/PE Ratio changes,
    # without re-hitting the Fyers API.
    if not df_mcx.empty and {"l1_ce", "l1_pe", "l2_ce", "l2_pe"}.issubset(df_mcx.columns):
        df_mcx = df_mcx.copy()
        df_mcx["ce_spread"] = df_mcx["l1_ce"] - df_mcx["l2_ce"] * mcx_l2_ce_ratio
        df_mcx["pe_spread"] = df_mcx["l1_pe"] - df_mcx["l2_pe"] * mcx_l2_pe_ratio

    # ── Results ──
    if df_mcx.empty:
        if not mcx_fetch_btn:
            st.info("👆 Select underlyings + strikes above, then click **Fetch MCX Data**.")
    else:
        latest_mcx   = df_mcx.iloc[-1]
        mcx_ce_val   = latest_mcx["ce_spread"]
        mcx_pe_val   = latest_mcx["pe_spread"]
        mcx_updated  = df_mcx.index[-1].strftime("%H:%M:%S")
        mcx_ce_delta = mcx_ce_val - df_mcx["ce_spread"].iloc[-2] if len(df_mcx) > 1 else 0
        mcx_pe_delta = mcx_pe_val - df_mcx["pe_spread"].iloc[-2] if len(df_mcx) > 1 else 0

        def _mcx_arrow(v):
            arrow = "▲" if v >= 0 else "▼"
            color = "#f87171" if v >= 0 else "#34d399"
            return f"<span style='color:{color};font-size:11px;font-family:\"Space Mono\",monospace;'>{arrow} {abs(v):.2f}</span>"

        # ── 3-card metrics (CE Spread | PE Spread | Last Update) ──
        st.markdown(f"""
        <div class="metrics-grid" style="grid-template-columns:repeat(3,1fr);">
            <div class="metric-card card-ce">
                <div class="metric-badge">📈</div>
                <div class="metric-label">CE SPREAD</div>
                <div class="metric-value val-ce">{mcx_ce_val:+.2f}</div>
                <div class="metric-sub">{mcx_l1_under} CE &minus; {mcx_l2_ce_ratio:g}×{mcx_l2_under} CE &nbsp; {_mcx_arrow(mcx_ce_delta)}</div>
            </div>
            <div class="metric-card card-pe">
                <div class="metric-badge">📉</div>
                <div class="metric-label">PE SPREAD</div>
                <div class="metric-value val-pe">{mcx_pe_val:+.2f}</div>
                <div class="metric-sub">{mcx_l1_under} PE &minus; {mcx_l2_pe_ratio:g}×{mcx_l2_under} PE &nbsp; {_mcx_arrow(mcx_pe_delta)}</div>
            </div>
            <div class="metric-card card-time">
                <div class="metric-badge">🕐</div>
                <div class="metric-label">LAST UPDATE</div>
                <div class="metric-value val-time">{mcx_updated}</div>
                <div class="metric-sub">{'LIVE' if mcx_date_str == date.today().strftime('%Y-%m-%d') else 'HISTORICAL'} &nbsp;&middot;&nbsp; {len(df_mcx)} candles</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        # ── Two separate chart sub-tabs ──
        _mcx_ct_ce, _mcx_ct_pe = st.tabs(["📈 CE Spread Chart", "📉 PE Spread Chart"])

        def _mcx_layout(fig, title, height=480):
            fig.update_layout(
                title=dict(text=title, font=dict(size=12, color=T["text2"]), x=0),
                height=height,
                plot_bgcolor=T["plot_bg"], paper_bgcolor=T["plot_bg"],
                font=dict(color=T["text2"], family="Space Mono"),
                hovermode="x unified",
                margin=dict(l=10, r=10, t=40, b=10),
                legend=dict(
                    bgcolor=T["card"], bordercolor=T["card_bdr"], borderwidth=1,
                    orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1,
                ),
                xaxis=dict(
                    gridcolor=T["grid"], tickfont=dict(size=10),
                    showspikes=True, spikemode="across",
                    spikecolor=T["text3"], spikethickness=1, spikedash="dot",
                ),
                yaxis=dict(
                    gridcolor=T["grid"], title="Spread (₹)", tickfont=dict(size=10),
                    showspikes=True, spikemode="across",
                    spikecolor=T["text3"], spikethickness=1, spikedash="dot",
                ),
                hoverlabel=dict(
                    bgcolor=T["card"], bordercolor=T["card_bdr"], font=dict(color=T["text"])
                ),
            )

        def _mcx_hlines(fig, series, color):
            h, l = series.max(), series.min()
            fig.add_hline(y=0, line_dash="dash", line_color="#555")
            fig.add_hline(
                y=h, line_dash="dot", line_color=color, line_width=1, opacity=0.65,
                annotation_text=f"H: {h:.2f}", annotation_position="right",
                annotation_font=dict(color=color, size=10),
            )
            fig.add_hline(
                y=l, line_dash="dot", line_color=color, line_width=1, opacity=0.65,
                annotation_text=f"L: {l:.2f}", annotation_position="right",
                annotation_font=dict(color=color, size=10),
            )

        _ce_label = f"{mcx_l1_under} CE − {mcx_l2_ce_ratio:g}×{mcx_l2_under} CE"
        _pe_label = f"{mcx_l1_under} PE − {mcx_l2_pe_ratio:g}×{mcx_l2_under} PE"

        with _mcx_ct_ce:
            fig_ce = go.Figure()
            fig_ce.add_trace(go.Scatter(
                x=df_mcx.index, y=df_mcx["ce_spread"],
                name=_ce_label,
                line=dict(color="#ff4444", width=2.5),
                fill="tozeroy", fillcolor="rgba(255,68,68,0.07)",
                hovertemplate="%{x|%H:%M}<br>CE Spread: %{y:.2f}<extra></extra>",
            ))
            _mcx_hlines(fig_ce, df_mcx["ce_spread"], "#ff4444")
            _mcx_layout(fig_ce, f"MCX CE Spread — {_ce_label}")
            st.plotly_chart(fig_ce, use_container_width=True)

            with st.expander("📋 CE Spread Data (last 20 candles)"):
                _d_ce = df_mcx[["l1_ce", "l2_ce", "ce_spread"]].tail(20).copy()
                _d_ce[f"{mcx_l2_ce_ratio:g}×{mcx_l2_under} CE"] = _d_ce["l2_ce"] * mcx_l2_ce_ratio
                _d_ce = _d_ce[["l1_ce", "l2_ce", f"{mcx_l2_ce_ratio:g}×{mcx_l2_under} CE", "ce_spread"]]
                _d_ce.columns = [
                    f"{mcx_l1_under} CE",
                    f"{mcx_l2_under} CE",
                    f"{mcx_l2_ce_ratio:g}×{mcx_l2_under} CE",
                    "CE Spread",
                ]
                _d_ce.index = _d_ce.index.strftime("%H:%M")
                st.dataframe(_d_ce.style.format("{:.2f}"), use_container_width=True)

        with _mcx_ct_pe:
            fig_pe = go.Figure()
            fig_pe.add_trace(go.Scatter(
                x=df_mcx.index, y=df_mcx["pe_spread"],
                name=_pe_label,
                line=dict(color="#44ff88", width=2.5),
                fill="tozeroy", fillcolor="rgba(68,255,136,0.07)",
                hovertemplate="%{x|%H:%M}<br>PE Spread: %{y:.2f}<extra></extra>",
            ))
            _mcx_hlines(fig_pe, df_mcx["pe_spread"], "#44ff88")
            _mcx_layout(fig_pe, f"MCX PE Spread — {_pe_label}")
            st.plotly_chart(fig_pe, use_container_width=True)

            with st.expander("📋 PE Spread Data (last 20 candles)"):
                _d_pe = df_mcx[["l1_pe", "l2_pe", "pe_spread"]].tail(20).copy()
                _d_pe[f"{mcx_l2_pe_ratio:g}×{mcx_l2_under} PE"] = _d_pe["l2_pe"] * mcx_l2_pe_ratio
                _d_pe = _d_pe[["l1_pe", "l2_pe", f"{mcx_l2_pe_ratio:g}×{mcx_l2_under} PE", "pe_spread"]]
                _d_pe.columns = [
                    f"{mcx_l1_under} PE",
                    f"{mcx_l2_under} PE",
                    f"{mcx_l2_pe_ratio:g}×{mcx_l2_under} PE",
                    "PE Spread",
                ]
                _d_pe.index = _d_pe.index.strftime("%H:%M")
                st.dataframe(_d_pe.style.format("{:.2f}"), use_container_width=True)

    _mcxlog("── tab5 render end ──")
    _refresh_log_top()

    # ── MCX Auto Refresh — flag for deferred rerun ──
    if mcx_auto and mcx_date_str == date.today().strftime("%Y-%m-%d") and not df_mcx.empty:
        st.session_state["_mcx_rerun_pending"] = True


# ─────────────────────────────────────────────
# DEFERRED AUTO-REFRESH — runs AFTER all tabs have rendered.
# Tab 1 / Tab 3 / Tab 5 each set a *_rerun_pending flag in session_state.
# We honor them here so no tab can short-circuit the rendering of another.
# ─────────────────────────────────────────────

_any_refresh = (
    st.session_state.pop("_main_rerun_pending", False)
    or st.session_state.pop("_iv_rerun_pending", False)
    or st.session_state.pop("_mcx_rerun_pending", False)
)
if _any_refresh:
    # Sleep once for the *shortest* configured interval (refresh_secs from Tab 1
    # is the canonical one), then refetch live tab-1 data and rerun.
    try:
        time.sleep(refresh_secs)
    except Exception:
        time.sleep(5)
    try:
        st.session_state.df = fetch_live_data()
    except Exception:
        pass
    st.rerun()
